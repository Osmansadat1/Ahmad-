import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Pause, Play, Sparkles } from 'lucide-react';

export interface ShowcaseItem {
  id: string;
  badge: string;
  title: string;
  description: string;
  style: string;
  roomType: string;
  beforeUrl: string;
  afterUrl: string;
  highlights: string[];
}

interface ShowcaseCarouselProps {
  items: ShowcaseItem[];
  onTryRoom: (id: string) => void;
}

const SLIDE_MS = 7500;

export const ShowcaseCarousel: React.FC<ShowcaseCarouselProps> = ({ items, onTryRoom }) => {
  const [index, setIndex] = useState(0);
  const [progress, setProgress] = useState(0); // 0..1 within the current slide
  const [manualPos, setManualPos] = useState<number | null>(null); // set while the visitor drags
  const [hovering, setHovering] = useState(false);
  const [userPaused, setUserPaused] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  const stageRef = useRef<HTMLDivElement | null>(null);
  const elapsedRef = useRef(0);
  const draggingRef = useRef(false);

  const count = items.length;
  const paused = userPaused || hovering || manualPos !== null || reducedMotion;

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const apply = () => setReducedMotion(mq.matches);
    apply();
    mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, []);

  const goTo = useCallback(
    (next: number) => {
      elapsedRef.current = 0;
      setProgress(0);
      setManualPos(null);
      setIndex(((next % count) + count) % count);
    },
    [count]
  );

  // Autoplay loop: the reveal line sweeps across, then the next slide appears.
  useEffect(() => {
    if (paused || count < 2) return;
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      elapsedRef.current += now - last;
      last = now;
      if (elapsedRef.current >= SLIDE_MS) {
        elapsedRef.current = 0;
        setProgress(0);
        setIndex((i) => (i + 1) % count);
      } else {
        setProgress(elapsedRef.current / SLIDE_MS);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [paused, count]);

  // 8% -> 92% -> 8% over one slide, smooth at both ends
  const autoPos = reducedMotion ? 50 : 50 - 42 * Math.cos(progress * Math.PI * 2);
  const pos = manualPos ?? autoPos;

  const posFromClientX = (clientX: number) => {
    const rect = stageRef.current?.getBoundingClientRect();
    if (!rect || rect.width <= 0) return 50;
    return Math.max(4, Math.min(96, ((clientX - rect.left) / rect.width) * 100));
  };

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    draggingRef.current = true;
    setManualPos(posFromClientX(e.clientX));
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };
  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (draggingRef.current) setManualPos(posFromClientX(e.clientX));
  };
  const onPointerUp = () => {
    draggingRef.current = false;
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowRight') goTo(index + 1);
    if (e.key === 'ArrowLeft') goTo(index - 1);
  };

  if (count === 0) return null;
  const active = items[index];

  return (
    <div
      role="region"
      aria-roledescription="carousel"
      aria-label="Before and after room makeovers"
      onKeyDown={onKeyDown}
      className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch"
    >
      {/* STAGE */}
      <div className="lg:col-span-8">
        <div
          ref={stageRef}
          tabIndex={0}
          onMouseEnter={() => setHovering(true)}
          onMouseLeave={() => {
            setHovering(false);
            setManualPos(null);
          }}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
          className="relative w-full aspect-[4/3] sm:aspect-[16/10] rounded-3xl overflow-hidden bg-[#EFE5D6] border border-[#E8E1D6] shadow-[0_24px_60px_-28px_rgba(31,77,61,0.35)] select-none touch-pan-y cursor-ew-resize focus:outline-none focus-visible:ring-4 focus-visible:ring-[#D9E7DC]"
        >
          {items.map((item, i) => {
            const isActive = i === index;
            return (
              <div
                key={item.id}
                aria-hidden={!isActive}
                className={`absolute inset-0 transition-all duration-700 ease-out ${
                  isActive ? 'opacity-100 scale-100' : 'opacity-0 scale-[1.03] pointer-events-none'
                }`}
              >
                <img src={item.afterUrl} alt={isActive ? `${item.title} — after` : ''} draggable={false} className="absolute inset-0 w-full h-full object-cover" />
                <img
                  src={item.beforeUrl}
                  alt={isActive ? `${item.title} — before` : ''}
                  draggable={false}
                  className="absolute inset-0 w-full h-full object-cover"
                  style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
                />
              </div>
            );
          })}

          {/* Labels */}
          <span
            className={`absolute top-4 left-4 px-3 py-1.5 rounded-full bg-[#1C2420]/70 backdrop-blur-sm text-[#FFFFFF] text-xs font-semibold transition-opacity duration-300 ${
              pos < 14 ? 'opacity-0' : 'opacity-100'
            }`}
          >
            Before
          </span>
          <span
            className={`absolute top-4 right-4 px-3 py-1.5 rounded-full bg-[#1F4D3D]/85 backdrop-blur-sm text-[#FFFFFF] text-xs font-semibold transition-opacity duration-300 ${
              pos > 86 ? 'opacity-0' : 'opacity-100'
            }`}
          >
            After
          </span>

          {/* Divider + handle */}
          <div className="absolute inset-y-0 w-0.5 bg-[#FFFFFF] shadow-[0_0_12px_rgba(0,0,0,0.35)] pointer-events-none" style={{ left: `${pos}%` }}>
            <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-[#FFFFFF] shadow-lg flex items-center justify-center text-[#1F4D3D]">
              <ArrowLeft className="w-3.5 h-3.5" />
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>

          {/* Demo disclosure */}
          <span className="absolute bottom-4 left-4 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#FFFFFF]/90 backdrop-blur-sm text-[11px] font-medium text-[#1C2420]">
            <Sparkles className="w-3 h-3 text-[#C2623F]" />
            Demo design concept · drag to compare
          </span>

          {/* Arrows */}
          <button
            type="button"
            aria-label="Previous makeover"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={() => goTo(index - 1)}
            className="absolute left-3 bottom-3 sm:top-1/2 sm:bottom-auto sm:-translate-y-1/2 w-10 h-10 rounded-full bg-[#FFFFFF]/90 hover:bg-[#FFFFFF] text-[#1C2420] shadow-md flex items-center justify-center cursor-pointer transition-colors hidden sm:flex"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            aria-label="Next makeover"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={() => goTo(index + 1)}
            className="absolute right-3 sm:top-1/2 sm:-translate-y-1/2 bottom-3 w-10 h-10 rounded-full bg-[#FFFFFF]/90 hover:bg-[#FFFFFF] text-[#1C2420] shadow-md flex items-center justify-center cursor-pointer transition-colors hidden sm:flex"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* DETAILS */}
      <div className="lg:col-span-4 flex flex-col justify-between gap-6">
        <div key={active.id} className="animate-[showcaseIn_0.6s_ease-out]" aria-live="polite">
          <span className="inline-block px-3 py-1 rounded-full bg-[#D9E7DC] text-[#1F4D3D] text-xs font-semibold">{active.badge}</span>
          <h3 className="mt-4 text-2xl sm:text-3xl font-semibold text-[#1C2420] tracking-tight">{active.title}</h3>
          <p className="mt-1 text-sm font-medium text-[#C2623F]">
            {active.style} · {active.roomType}
          </p>
          <p className="mt-3 text-sm sm:text-base text-[#667067] leading-relaxed">{active.description}</p>
          <ul className="mt-4 space-y-2">
            {active.highlights.map((h) => (
              <li key={h} className="flex items-center gap-2 text-sm text-[#1C2420]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#1F4D3D]" aria-hidden="true" />
                {h}
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={() => onTryRoom(active.id)}
            className="mt-6 inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#1F4D3D] text-[#FFFFFF] text-sm font-semibold hover:bg-[#153A2E] transition-colors cursor-pointer"
          >
            Try this room free <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Slide selector with progress */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-[#667067] tabular-nums">
              {String(index + 1).padStart(2, '0')} / {String(count).padStart(2, '0')}
            </span>
            {!reducedMotion && (
              <button
                type="button"
                onClick={() => setUserPaused((p) => !p)}
                aria-label={userPaused ? 'Play slideshow' : 'Pause slideshow'}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-[#667067] hover:text-[#1C2420] cursor-pointer"
              >
                {userPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                {userPaused ? 'Play' : 'Pause'}
              </button>
            )}
          </div>
          <div className="grid grid-cols-4 gap-2.5">
            {items.map((item, i) => (
              <button
                key={item.id}
                type="button"
                onClick={() => goTo(i)}
                aria-label={`Show ${item.title}`}
                aria-current={i === index}
                className={`relative rounded-xl overflow-hidden aspect-[4/3] border-2 transition-all cursor-pointer ${
                  i === index ? 'border-[#1F4D3D] shadow-md' : 'border-transparent opacity-70 hover:opacity-100'
                }`}
              >
                <img src={item.afterUrl} alt="" draggable={false} className="w-full h-full object-cover" />
                {i === index && (
                  <span className="absolute inset-x-0 bottom-0 h-1 bg-[#FFFFFF]/50">
                    <span className="block h-full bg-[#C2623F]" style={{ width: `${progress * 100}%` }} />
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
