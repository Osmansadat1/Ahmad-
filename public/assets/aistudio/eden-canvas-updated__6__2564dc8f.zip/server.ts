import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { defaultCreditStore } from './src/server/creditSystem';
import { PackagePlanId } from './src/types/pricing';

dotenv.config();

const PORT = 3000;
const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

function hasConfiguredApiKey(): boolean {
  const key = process.env.GEMINI_API_KEY;
  return Boolean(key && key.trim() !== '' && key !== 'MY_GEMINI_API_KEY');
}

function getGenAIClient(): GoogleGenAI | null {
  if (!hasConfiguredApiKey()) return null;
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();

  app.use(express.json({ limit: '15mb' }));

  app.get('/api/status', (_req, res) => {
    const apiKeyConfigured = hasConfiguredApiKey();
    const paymentStatus = defaultCreditStore.getPaymentEnvironmentStatus();
    res.json({
      service: 'Eden Canvas AI Engine & Credit Ledger',
      apiKeyConfigured,
      mode: apiKeyConfigured ? 'live_ready' : 'demo_mode',
      paymentStatus,
      message: apiKeyConfigured
        ? 'Server-side Gemini API key detected. Image-to-image redesign will attempt live generation first and fall back to Demo Mode if image quota is exhausted.'
        : 'No GEMINI_API_KEY configured. Running in transparent Demo Mode.',
    });
  });

  /**
   * 1. Public Pricing & Package Configuration (Server-Authoritative)
   */
  app.get('/api/pricing/config', (_req, res) => {
    const cfg = defaultCreditStore.getConfig();
    res.json({
      config: cfg,
      pricing: cfg,
      paymentEnvironment: defaultCreditStore.getPaymentEnvironmentStatus(),
    });
  });

  /**
   * 2. Account Session Provisioning & Verification
   * Creates an isolated server account with the initial 3 Free Trial credits,
   * or verifies and returns an existing account when valid credentials are provided.
   */
  const handleCreditsSession = (req: express.Request, res: express.Response) => {
    try {
      const accountId = String(
        req.body?.accountId || req.headers['x-account-id'] || ''
      );
      const sessionToken = String(
        req.body?.sessionToken || req.headers['x-session-token'] || ''
      );
      if (accountId && sessionToken) {
        try {
          const summary = defaultCreditStore.getAccountSummary(accountId, sessionToken);
          res.json({
            accountId,
            sessionToken,
            summary,
            createdNew: false,
          });
          return;
        } catch {
          // If stale or invalid after server restart, provision a fresh isolated session
        }
      }
      const created = defaultCreditStore.createAccount();
      res.status(201).json({
        ...created,
        createdNew: true,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to initialize credit session.';
      res.status(500).json({ error: msg });
    }
  };

  app.post('/api/credits/session', handleCreditsSession);
  app.get('/api/credits/session', handleCreditsSession);

  /**
   * 3. Authenticated Account Balance & Ledger Lookup
   * Rejects unauthenticated or cross-account access attempts.
   */
  app.get('/api/credits/balance', (req, res) => {
    try {
      const accountId = String(req.headers['x-account-id'] || req.query.accountId || '');
      const sessionToken = String(req.headers['x-session-token'] || '');
      const summary = defaultCreditStore.getAccountSummary(accountId, sessionToken);
      res.json({ summary });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unauthorized account balance request.';
      const status = msg.includes('UNAUTHORIZED') ? 401 : msg.includes('NOT_FOUND') ? 404 : 400;
      res.status(status).json({ error: msg });
    }
  });

  /**
   * 4. Create Server-Validated Checkout Session
   * Ignores any client-sent price or credit count; uses server-side package config.
   */
  app.post('/api/payments/checkout-session', (req, res) => {
    try {
      const accountId = String(req.headers['x-account-id'] || req.body?.accountId || '');
      const sessionToken = String(req.headers['x-session-token'] || req.body?.sessionToken || '');
      const packageId = String(req.body?.packageId || '') as PackagePlanId;
      const appBaseUrl = process.env.APP_URL && process.env.APP_URL !== 'MY_APP_URL'
        ? process.env.APP_URL
        : `${req.protocol}://${req.get('host')}`;

      const session = defaultCreditStore.createCheckoutSession({
        accountId,
        sessionToken,
        packageId,
        appBaseUrl,
      });

      res.status(201).json({
        session,
        paymentEnvironment: defaultCreditStore.getPaymentEnvironmentStatus(),
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unable to create checkout session.';
      const status = msg.includes('UNAUTHORIZED') ? 401 : 400;
      res.status(status).json({ error: msg });
    }
  });

  /**
   * 5. Inspect Checkout Session Status
   */
  app.get('/api/payments/checkout-session/:sessionId', (req, res) => {
    try {
      const accountId = String(req.headers['x-account-id'] || '');
      const sessionToken = String(req.headers['x-session-token'] || '');
      const session = defaultCreditStore.getCheckoutSession(
        req.params.sessionId,
        accountId,
        sessionToken
      );
      const summary = defaultCreditStore.getAccountSummary(accountId, sessionToken);
      res.json({ session, summary });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Checkout session lookup failed.';
      const status = msg.includes('UNAUTHORIZED') ? 401 : 404;
      res.status(status).json({ error: msg });
    }
  });

  /**
   * 6. Development Sandbox Checkout Resolver
   * Clearly labeled for development/demo mode only when live payment gateway keys are not configured.
   */
  app.post('/api/payments/dev-resolve-checkout', (req, res) => {
    try {
      const accountId = String(req.headers['x-account-id'] || req.body?.accountId || '');
      const sessionToken = String(req.headers['x-session-token'] || req.body?.sessionToken || '');
      const { sessionId, outcome, customWebhookEventId } = req.body || {};

      // Verify ownership of session first
      defaultCreditStore.getCheckoutSession(String(sessionId || ''), accountId, sessionToken);

      const eventMap: Record<
        string,
        'checkout.completed' | 'checkout.cancelled' | 'payment.failed' | 'payment.refunded'
      > = {
        completed: 'checkout.completed',
        cancelled: 'checkout.cancelled',
        failed: 'payment.failed',
        refunded: 'payment.refunded',
      };

      const eventType = eventMap[String(outcome || '')];
      if (!eventType) {
        res.status(400).json({ error: 'Invalid checkout resolution outcome.' });
        return;
      }

      const webhookEventId =
        typeof customWebhookEventId === 'string' && customWebhookEventId.trim()
          ? customWebhookEventId.trim()
          : `evt_dev_${sessionId}_${outcome}`;

      const result = defaultCreditStore.processPaymentWebhookEvent({
        webhookEventId,
        sessionId: String(sessionId),
        eventType,
        isDevelopmentSandboxAction: true,
      });

      const summary = defaultCreditStore.getAccountSummary(accountId, sessionToken);
      res.json({
        ...result,
        summary,
        developmentModeNotice:
          'Resolved in Development Demo Checkout Mode. No live credit card was charged.',
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to resolve development checkout.';
      const status = msg.includes('UNAUTHORIZED') ? 401 : 400;
      res.status(status).json({ error: msg });
    }
  });

  /**
   * 7. Signed Payment Provider Webhook Endpoint
   * Idempotent by webhookEventId; verifies HMAC-SHA256 signature when PAYMENT_WEBHOOK_SECRET is configured.
   */
  app.post('/api/webhooks/payment', (req, res) => {
    try {
      const signature = String(req.headers['x-webhook-signature'] || '');
      const { webhookEventId, sessionId, eventType } = req.body || {};
      if (!webhookEventId || !sessionId || !eventType) {
        res.status(400).json({ error: 'Missing required webhook fields (webhookEventId, sessionId, eventType).' });
        return;
      }

      const result = defaultCreditStore.processPaymentWebhookEvent({
        webhookEventId: String(webhookEventId),
        sessionId: String(sessionId),
        eventType,
        rawPayload: JSON.stringify(req.body),
        signatureHeader: signature,
        isDevelopmentSandboxAction: false,
      });

      res.json({
        received: true,
        idempotentDuplicate: result.idempotentDuplicate,
        sessionStatus: result.session.status,
        creditsDelta: result.creditsDelta,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Webhook processing error.';
      const status = msg.includes('SIGNATURE') ? 401 : 400;
      res.status(status).json({ error: msg });
    }
  });

  /**
   * 8. Protected Server-Side Admin Pricing & Credit Configuration
   */
  app.put('/api/admin/pricing', (req, res) => {
    try {
      const adminToken = String(req.headers['x-admin-token'] || '');
      const updatedConfig = defaultCreditStore.updateAdminPricingConfig(adminToken, req.body || {});
      res.json({
        config: updatedConfig,
        message: 'Server pricing and credit configuration updated.',
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Admin update rejected.';
      const status = msg.includes('ADMIN_UNAUTHORIZED') ? 403 : 400;
      res.status(status).json({ error: msg });
    }
  });

  /**
   * 9. AI Room Redesign Endpoint with Atomic Server-Side Credit Deduction & Automatic Failure Refund
   */
  app.post('/api/redesign', async (req, res) => {
    const accountId = String(req.headers['x-account-id'] || req.body?.accountId || '');
    const sessionToken = String(req.headers['x-session-token'] || req.body?.sessionToken || '');
    const operationId = String(req.body?.operationId || `op_${Date.now()}`);

    try {
      const {
        imageBase64,
        mimeType,
        prompt,
        preferences,
        simulateError,
        requireLiveAi,
      } = req.body || {};

      if (!imageBase64 || typeof imageBase64 !== 'string') {
        res.status(400).json({
          code: 'MISSING_PHOTO',
          error: 'Missing room photo data. Please upload a valid JPEG, PNG, or WebP room image.',
        });
        return;
      }

      const cleanMime = mimeType || 'image/png';
      if (!ALLOWED_MIME_TYPES.includes(cleanMime)) {
        res.status(400).json({
          code: 'UNSUPPORTED_FORMAT',
          error: `Unsupported image MIME type (${cleanMime}). Please upload a JPEG, PNG, or WebP photo.`,
        });
        return;
      }

      if (!prompt || typeof prompt !== 'string') {
        res.status(400).json({
          code: 'MISSING_PROMPT',
          error: 'Missing redesign instructions.',
        });
        return;
      }

      // Server-side credit balance validation & reservation BEFORE running generation
      if (accountId && sessionToken) {
        try {
          defaultCreditStore.reserveCreditsForGeneration({
            accountId,
            sessionToken,
            operationId,
            roomType: preferences?.roomType || 'Living Room',
            style: preferences?.style || 'Organic Modern',
          });
        } catch (creditErr: unknown) {
          const msg = creditErr instanceof Error ? creditErr.message : 'Insufficient credits.';
          const isInsufficient = msg.includes('INSUFFICIENT_CREDITS');
          res.status(isInsufficient ? 402 : 401).json({
            code: isInsufficient ? 'INSUFFICIENT_CREDITS' : 'UNAUTHORIZED_CREDIT_ACCOUNT',
            error: msg,
          });
          return;
        }
      }

      // Helper to refund credit on any generation failure
      const refundOnFailure = (reason: string) => {
        if (!accountId || !sessionToken) return null;
        return defaultCreditStore.failAndRefundGenerationOperation({
          accountId,
          sessionToken,
          operationId,
          errorMessage: reason,
        });
      };

      // Support explicit failure/timeout/credential testing for QA verification
      if (simulateError === 'invalid_key') {
        const refundInfo = refundOnFailure('Simulated invalid API key error');
        res.status(401).json({
          code: 'INVALID_API_KEY',
          error:
            'Invalid or unauthorized API key. Your deducted credit was automatically refunded to your balance.',
          creditRefunded: refundInfo?.refunded ?? false,
          accountSummary: refundInfo?.summary ?? null,
        });
        return;
      }
      if (simulateError === 'rate_limit') {
        const refundInfo = refundOnFailure('Simulated HTTP 429 rate limit');
        res.status(429).json({
          code: 'RATE_LIMIT',
          error:
            'AI service rate limit reached (HTTP 429). Your deducted credit was automatically refunded to your balance.',
          creditRefunded: refundInfo?.refunded ?? false,
          accountSummary: refundInfo?.summary ?? null,
        });
        return;
      }
      if (simulateError === 'timeout') {
        const refundInfo = refundOnFailure('Simulated provider timeout');
        res.status(504).json({
          code: 'TIMEOUT',
          error:
            'The room generation request timed out. Your deducted credit was automatically refunded to your balance.',
          creditRefunded: refundInfo?.refunded ?? false,
          accountSummary: refundInfo?.summary ?? null,
        });
        return;
      }

      const ai = getGenAIClient();
      if (!ai) {
        if (requireLiveAi) {
          const refundInfo = refundOnFailure('Missing GEMINI_API_KEY while requireLiveAi enabled');
          res.status(401).json({
            code: 'MISSING_CREDENTIALS',
            error:
              'GEMINI_API_KEY is not configured in server environment secrets. Your deducted credit was automatically refunded.',
            creditRefunded: refundInfo?.refunded ?? false,
            accountSummary: refundInfo?.summary ?? null,
          });
          return;
        }

        const updatedSummary =
          accountId && sessionToken
            ? defaultCreditStore.completeGenerationOperation({
                accountId,
                sessionToken,
                operationId,
                mode: 'demo_fallback',
              })
            : null;

        res.json({
          mode: 'demo_fallback',
          modeReason:
            'GEMINI_API_KEY is not configured in environment secrets. Showing a clearly labeled Demo Mode architectural visualization (not a real AI output).',
          generatedImageDataUrl: null,
          receivedPrompt: prompt,
          receivedPreferences: preferences,
          accountSummary: updatedSummary,
          designSummary: `Demo Mode Concept (Not Live AI) for your ${preferences?.roomType || 'room'} in ${
            preferences?.style || 'Organic Modern'
          } style (${preferences?.budget || '$300–$500'}).`,
        });
        return;
      }

      let cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z+]+;base64,/, '');
      if (imageBase64.startsWith('/images/')) {
        try {
          const fs = await import('fs');
          const filePath = path.join(process.cwd(), 'public', imageBase64);
          if (fs.existsSync(filePath)) {
            cleanBase64 = fs.readFileSync(filePath).toString('base64');
          }
        } catch {
          // Fallback to existing string if read fails
        }
      }

      try {
        const imageResponse = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite-image',
          contents: {
            parts: [
              {
                inlineData: {
                  data: cleanBase64,
                  mimeType: cleanMime,
                },
              },
              {
                text: prompt,
              },
            ],
          },
        });

        let generatedBase64: string | null = null;
        let modelNote = '';
        const parts = imageResponse.candidates?.[0]?.content?.parts || [];
        for (const part of parts) {
          if (part.inlineData?.data) {
            generatedBase64 = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
          } else if (part.text) {
            modelNote += part.text;
          }
        }

        if (generatedBase64) {
          const updatedSummary =
            accountId && sessionToken
              ? defaultCreditStore.completeGenerationOperation({
                  accountId,
                  sessionToken,
                  operationId,
                  mode: 'live_ai',
                })
              : null;

          res.json({
            mode: 'live_ai',
            generatedImageDataUrl: generatedBase64,
            receivedPrompt: prompt,
            receivedPreferences: preferences,
            accountSummary: updatedSummary,
            designSummary:
              modelNote.trim() ||
              `AI-generated ${preferences?.style || 'Organic Modern'} redesign preserving your ${
                preferences?.roomType?.toLowerCase() || 'room'
              } architecture and active rental rules.`,
          });
          return;
        }
      } catch (imgErr: unknown) {
        const errMessage = imgErr instanceof Error ? imgErr.message : String(imgErr);
        const isQuotaOrBilling =
          errMessage.includes('resource_exhausted') ||
          errMessage.includes('429') ||
          errMessage.includes('quota') ||
          errMessage.includes('billing') ||
          errMessage.includes('API key');

        if (requireLiveAi) {
          const refundInfo = refundOnFailure(errMessage);
          res.status(isQuotaOrBilling ? 429 : 502).json({
            code: isQuotaOrBilling ? 'RATE_LIMIT' : 'PROVIDER_ERROR',
            error: isQuotaOrBilling
              ? 'Live Gemini image model quota is currently exhausted (HTTP 429). Your deducted credit was automatically refunded.'
              : `Live AI provider error: ${errMessage.slice(0, 140)}. Your deducted credit was automatically refunded.`,
            creditRefunded: refundInfo?.refunded ?? false,
            accountSummary: refundInfo?.summary ?? null,
          });
          return;
        }

        const updatedSummary =
          accountId && sessionToken
            ? defaultCreditStore.completeGenerationOperation({
                accountId,
                sessionToken,
                operationId,
                mode: 'demo_fallback',
              })
            : null;

        res.json({
          mode: 'demo_fallback',
          modeReason: isQuotaOrBilling
            ? 'Live image generation model quota is currently exhausted or requires a billed API key tier. Showing a clearly labeled Demo Mode architectural preview (not a real AI output) so you can test the full renter workflow.'
            : `Live image generation unavailable (${errMessage.slice(0, 120)}). Showing clearly labeled Demo Mode preview (not a real AI output).`,
          generatedImageDataUrl: null,
          receivedPrompt: prompt,
          receivedPreferences: preferences,
          accountSummary: updatedSummary,
          designSummary: `Demo Mode Concept (Not Live AI) tailored for your ${preferences?.roomType || 'room'} in ${
            preferences?.style || 'Organic Modern'
          } style (${preferences?.budget || '$300–$500'}).`,
        });
        return;
      }

      const updatedSummary =
        accountId && sessionToken
          ? defaultCreditStore.completeGenerationOperation({
              accountId,
              sessionToken,
              operationId,
              mode: 'demo_fallback',
            })
          : null;

      res.json({
        mode: 'demo_fallback',
        modeReason:
          'The image model did not return an inline image payload. Showing a clearly labeled Demo Mode architectural preview (not a real AI output).',
        generatedImageDataUrl: null,
        receivedPrompt: prompt,
        receivedPreferences: preferences,
        accountSummary: updatedSummary,
        designSummary: `Demo Mode Concept (Not Live AI) for your ${preferences?.roomType || 'room'} in ${
          preferences?.style || 'Organic Modern'
        } style.`,
      });
    } catch (error: unknown) {
      const message =
        error instanceof Error ? error.message : 'Unexpected server error during room redesign.';
      if (accountId && sessionToken) {
        defaultCreditStore.failAndRefundGenerationOperation({
          accountId,
          sessionToken,
          operationId,
          errorMessage: message,
        });
      }
      res.status(500).json({ error: message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Eden Canvas server running on http://localhost:${PORT}`);
  });
}

startServer();
