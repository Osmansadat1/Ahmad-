import React, { useState, useRef, useCallback } from 'react';
import { MoveHorizontal, Columns2, SlidersHorizontal } from 'lucide-react';

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
  isDemoConcept?: boolean;
  styleName?: string;
  roomTypeName?: string;
  compact?: boolean;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({
  beforeImage,
  afterImage,
  beforeLabel = 'Before — Original Room',
  afterLabel,
  isDemoConcept = false,
  styleName = 'Organic Modern',
  roomTypeName = 'Living Room',
  compact = false,
}) => {
  const [sliderPosition, setSliderPosition] = useState<number>(42);
  const [viewMode, setViewMode] = useState<'slider' | 'side-by-side'>('slider');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const resolvedAfterLabel =
    afterLabel || (isDemoConcept ? 'After — Sample Concept Preview' : 'After — AI Design Concept');

  const updateSliderFromClientX = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    if (rect.width <= 0) return;
    const relativeX = clientX - rect.left;
    const percentage = Math.max(4, Math.min(96, (relativeX / rect.width) * 100));
    setSliderPosition(Math.round(percentage));
  }, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (viewMode !== 'slider') return;
    setIsDragging(true);
    updateSliderFromClientX(e.clientX);
    if (e.currentTarget.setPointerCapture) {
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Ignore synthetic events without active pointerId
      }
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging || viewMode !== 'slider') return;
    updateSliderFromClientX(e.clientX);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    setIsDragging(false);
    if (e.currentTarget.hasPointerCapture && e.currentTarget.hasPointerCapture(e.pointerId)) {
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        // Ignore synthetic events
      }
    }
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (viewMode !== 'slider') return;
    const touch = e.touches[0];
    if (touch) {
      setIsDragging(true);
      updateSliderFromClientX(touch.clientX);
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (viewMode !== 'slider') return;
    const touch = e.touches[0];
    if (touch) {
      updateSliderFromClientX(touch.clientX);
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      setSliderPosition((prev) => Math.max(5, prev - 5));
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      setSliderPosition((prev) => Math.min(95, prev + 5));
    } else if (e.key === 'Home') {
      e.preventDefault();
      setSliderPosition(10);
    } else if (e.key === 'End') {
      e.preventDefault();
      setSliderPosition(90);
    }
  };

  return (
    <div className="w-full">
      {/* View toggle header */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-1.5 text-xs text-[#667067] truncate max-w-full">
          <span className="font-semibold text-[#1C2420] truncate">{roomTypeName}</span>
          <span aria-hidden="true">·</span>
          <span className="truncate">{styleName}</span>
          {!compact && (
            <>
              <span aria-hidden="true">·</span>
              <span className="text-[#1F4D3D] font-semibold truncate">
                {isDemoConcept ? 'Sample Concept Preview' : 'AI Design Concept'}
              </span>
            </>
          )}
        </div>

        <div className="flex items-center gap-1 p-1 bg-[#F3EDE2] rounded-xl border border-[#E8E1D6]">
          <button
            type="button"
            onClick={() => setViewMode('slider')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              viewMode === 'slider'
                ? 'bg-[#FFFFFF] text-[#1C2420] shadow-2xs border border-[#E8E1D6]'
                : 'text-[#667067] hover:text-[#1C2420]'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            Interactive Slider
          </button>
          <button
            type="button"
            onClick={() => setViewMode('side-by-side')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              viewMode === 'side-by-side'
                ? 'bg-[#FFFFFF] text-[#1C2420] shadow-2xs border border-[#E8E1D6]'
                : 'text-[#667067] hover:text-[#1C2420]'
            }`}
          >
            <Columns2 className="w-3.5 h-3.5" />
            Side by Side
          </button>
        </div>
      </div>

      {viewMode === 'slider' ? (
        <div
          ref={containerRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onKeyDown={handleKeyDown}
          role="slider"
          tabIndex={0}
          aria-label="Before and after room design comparison slider"
          aria-valuemin={5}
          aria-valuemax={95}
          aria-valuenow={sliderPosition}
          className="relative w-full overflow-hidden rounded-2xl border border-[#E8E1D6] bg-[#FAF7F2] select-none cursor-ew-resize touch-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1F4D3D] aspect-16/10 shadow-xs"
        >
          {/* Base Image: AFTER */}
          {afterImage ? (
            <img
              src={afterImage}
              alt={`${resolvedAfterLabel} in ${styleName} style`}
              referrerPolicy="no-referrer"
              draggable={false}
              style={
                beforeImage === afterImage
                  ? { filter: 'saturate(1.14) contrast(1.05) brightness(1.02) sepia(0.06)' }
                  : undefined
              }
              className="w-full h-full object-cover block pointer-events-none"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-sm text-[#667067]">
              {resolvedAfterLabel}
            </div>
          )}

          {/* Clipped Overlay Image: BEFORE (Original Room) */}
          <div
            className="absolute inset-0 overflow-hidden pointer-events-none"
            style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
          >
            {beforeImage ? (
              <img
                src={beforeImage}
                alt={beforeLabel}
                referrerPolicy="no-referrer"
                draggable={false}
                style={
                  isDemoConcept
                    ? { filter: 'saturate(0.38) contrast(0.88) brightness(0.93) hue-rotate(-10deg)' }
                    : undefined
                }
                className="w-full h-full object-cover block pointer-events-none"
              />
            ) : (
              <div className="w-full h-full bg-[#FAF7F2] flex items-center justify-center text-sm text-[#667067]">
                Original Room Preview
              </div>
            )}
          </div>

          {/* Measured Top Scrim for Readable Labels */}
          <div className="absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-black/55 via-black/20 to-transparent pointer-events-none" />

          {/* Clear Before & After Labels */}
          <div className="absolute top-3 left-3 sm:top-3.5 sm:left-4 pointer-events-none max-w-[44%]">
            <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-black/55 backdrop-blur-xs text-[11px] sm:text-xs font-medium tracking-wide text-white truncate">
              <span className="sm:hidden">Before</span>
              <span className="hidden sm:inline">{beforeLabel}</span>
            </span>
          </div>

          <div className="absolute top-3 right-3 sm:top-3.5 sm:right-4 text-right pointer-events-none max-w-[52%]">
            <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-[#1F4D3D]/95 backdrop-blur-xs text-[11px] sm:text-xs font-medium tracking-wide text-white truncate">
              <span className="sm:hidden">
                {isDemoConcept ? 'After (Sample)' : 'After (AI)'}
              </span>
              <span className="hidden sm:inline">{resolvedAfterLabel}</span>
            </span>
          </div>

          {/* Vertical Divider Line & Handle */}
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_10px_rgba(0,0,0,0.3)] pointer-events-none"
            style={{ left: `${sliderPosition}%` }}
          >
            <div className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white text-[#1C2420] shadow-md border border-[#E8E1D6] flex items-center justify-center">
              <MoveHorizontal className="w-4 h-4 text-[#1F4D3D]" />
            </div>
          </div>

          {/* Bottom instruction hint */}
          <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-black/55 to-transparent pointer-events-none flex items-end justify-between px-3.5 sm:px-4 pb-2.5 text-[11px] text-white/95">
            <span className="truncate">Drag handle to compare before &amp; after</span>
            <span className="hidden sm:inline font-mono tabular-nums shrink-0">
              {sliderPosition}% Before / {100 - sliderPosition}% After
            </span>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative overflow-hidden rounded-2xl border border-[#E8E1D6] bg-[#FAF7F2] aspect-16/10">
            {beforeImage && (
              <img
                src={beforeImage}
                alt={beforeLabel}
                referrerPolicy="no-referrer"
                style={
                  isDemoConcept
                    ? { filter: 'saturate(0.38) contrast(0.88) brightness(0.93) hue-rotate(-10deg)' }
                    : undefined
                }
                className="w-full h-full object-cover"
              />
            )}
            <div className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-black/55 to-transparent p-3.5">
              <span className="text-xs font-medium text-white">{beforeLabel}</span>
            </div>
          </div>

          <div className="relative overflow-hidden rounded-2xl border border-[#E8E1D6] bg-[#FAF7F2] aspect-16/10">
            {afterImage && (
              <img
                src={afterImage}
                alt={`${resolvedAfterLabel} in ${styleName} style`}
                referrerPolicy="no-referrer"
                style={
                  beforeImage === afterImage
                    ? { filter: 'saturate(1.14) contrast(1.05) brightness(1.02) sepia(0.06)' }
                    : undefined
                }
                className="w-full h-full object-cover"
              />
            )}
            <div className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-black/55 to-transparent p-3.5 flex items-center justify-between">
              <span className="text-xs font-medium text-white">{resolvedAfterLabel}</span>
              <span className="text-[11px] text-white/90">{styleName}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
