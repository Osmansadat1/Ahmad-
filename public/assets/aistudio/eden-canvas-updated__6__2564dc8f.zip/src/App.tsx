import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Check,
  ChevronDown,
  ChevronUp,
  ClipboardList,
  Clock,
  Coins,
  Download,
  Home,
  Image as ImageIcon,
  Info,
  Layers,
  Lock,
  Maximize2,
  Menu,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  Sliders,
  Sofa,
  Sparkles,
  Upload,
  User,
  Wallet,
  X,
} from 'lucide-react';
import {
  AnalyticsEventName,
  AnalyticsEventRecord,
  BudgetIntent,
  BudgetTier,
  CreditState,
  DesignStyle,
  ExistingFurnitureMode,
  PreservedArchitecture,
  RedesignPreferences,
  RedesignResult,
  RentalRules,
  RoomType,
} from './types/eden';
import {
  BUDGET_INTENT_OPTIONS,
  DEFAULT_PREFERENCES,
  DESIGN_STYLES,
  EXISTING_FURNITURE_MODES,
  IDENTIFIABLE_FURNITURE_CHIPS,
  IMPROVEMENT_GOALS,
  PRESERVED_ARCHITECTURE_DEFINITIONS,
  RENTAL_RULE_DEFINITIONS,
  RENTER_VALIDATION_SCENARIOS,
  ROOM_TYPES,
  RenterValidationScenario,
  buildActionablePlan,
  buildArchitecturalNotes,
  buildComplianceSummary,
  buildRedesignPrompt,
  buildSmallSpaceNotes,
  calculateBudgetSummary,
  consumeDesignCredit,
  createAnalyticsEvent,
  createInitialCreditState,
  formatApiErrorMessage,
  reviseRecommendationsToFitBudget,
  selectRecommendations,
  validatePhotoUpload,
} from './utils/designEngine';
import {
  SAMPLE_ROOM_PRESETS,
  SampleRoomPreset,
  createDemoTransformationFromUpload,
  renderRoomSceneToDataUrl,
  renderStyleCardVisual,
} from './utils/roomCanvasGenerator';
import { BeforeAfterSlider } from './components/BeforeAfterSlider';
import { ShowcaseCarousel } from './components/ShowcaseCarousel';
import { ChoiceList } from './components/ChoiceList';
import { ShoppableSection } from './components/ShoppableSection';
import { PolicyDocType, PricingPage } from './components/PricingPage';
import { AccountBalanceSummary, PricingSystemConfig } from './types/pricing';

type LegalModalType = 'privacy' | 'terms' | 'refund' | 'contact' | 'login' | null;

interface UploadedRoomPhoto {
  id: string;
  name: string;
  mimeType: string;
  sizeBytes: number;
  dataUrl: string;
  isSample: boolean;
  sampleId?: string;
}

const GENERATION_STEPS = [
  'Analyzing your room layout, natural light, and preserved features...',
  'Applying your existing furniture, small-space, and rental rules...',
  'Building your design concept, action plan, and budget-aware shopping list...',
];

const FAQ_ITEMS: { question: string; answer: string }[] = [
  {
    question: 'How does Eden Canvas redesign my room?',
    answer:
      'You start by uploading a photo of your room (or selecting a sample room), identifying furniture you already own, and choosing your room type, design style, maximum spending budget, and rental restrictions. Eden Canvas compiles those choices into a structured redesign instruction and generates a visual concept, a step-by-step action plan, and a budget-aware shopping list.',
  },
  {
    question: 'Can I design a rental without painting or drilling?',
    answer:
      'Yes. You can enable No Painting, No Drilling, No Hardwiring, No Permanent Adhesives, Removable Decor Only, Keep Existing Fixtures, and Preserve Room Layout. Please note that lease terms and wall finishes vary—even removable products can damage delicate surfaces, so always verify your lease agreement before installing hardware or adhesives.',
  },
  {
    question: 'Can I keep my existing furniture?',
    answer:
      'Yes. In the "What I Already Own?" section, you can choose to keep all existing furniture where possible, keep selected furniture, or replace only what is necessary. Our action plan always starts with $0 free adjustments—rearranging and styling what you already own—before suggesting new purchases.',
  },
  {
    question: 'Can I work within a specific budget?',
    answer:
      'Yes. You can set a maximum dollar cap (such as $0, $50, $250, or $500) and choose whether to use existing items only or add a few affordable upgrades. We calculate the verified product subtotal from verified prices, flag any excess over your budget with a one-click "Revise to Fit My Budget" button, and clearly note when shipping, taxes, or unverified prices are excluded.',
  },
  {
    question: 'Will the generated image match my actual room exactly?',
    answer:
      'Generated visuals are design concepts created for inspiration. While your architectural preservation settings (wall colors, flooring, windows, doors, built-ins, and layout) are included in the generation instructions, AI concepts may still alter surface details, and retail furniture dimensions or finishes may differ from the concept image.',
  },
  {
    question: 'Do I need to purchase new furniture?',
    answer:
      'No. Purchasing new furniture is completely optional. You can select "Use existing items only" ($0 budget) to receive a layout, lighting, and decluttering action plan tailored around the items you already own.',
  },
  {
    question: 'How do design credits and paid packages work?',
    answer:
      'Every new session starts with 3 free trial credits (each room redesign uses 1 credit). When you need more, you can choose a one-time credit package on the Pricing page: Starter ($5.99 for 20 credits), Room Refresh ($12.00 for 50 credits, valid for 6 months), or Home Makeover ($24.00 for 120 credits). If a generation ever fails due to a technical error, your credit is refunded automatically.',
  },
];

const HOME_FAQ_ITEMS = [0, 1, 3, 5].map((i) => FAQ_ITEMS[i]).filter(Boolean);

export default function App() {
  // Route state ('/', '/pricing' or '/try') synced with browser URL
  const [currentRoute, setCurrentRoute] = useState<'/' | '/pricing' | '/try'>(() => {
    if (typeof window === 'undefined') return '/';
    const p = window.location.pathname;
    if (p.startsWith('/pricing')) return '/pricing';
    if (p.startsWith('/try')) return '/try';
    return '/';
  });
  const [activePolicyDoc, setActivePolicyDoc] = useState<PolicyDocType | null>(null);

  // Navigation & UI state
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [legalModal, setLegalModal] = useState<LegalModalType>(null);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [showPromptInspector, setShowPromptInspector] = useState(false);
  const [showAdvancedControls, setShowAdvancedControls] = useState(false);
  const [activeScenarioId, setActiveScenarioId] = useState<string | null>(null);

  // Server capability state
  const [aiConfigured, setAiConfigured] = useState<boolean>(false);
  const [preferDemoMode, setPreferDemoMode] = useState<boolean>(false);

  // User Room Photo & Preferences
  const [uploadedPhoto, setUploadedPhoto] = useState<UploadedRoomPhoto | null>(null);
  const [activeSamplePresetId, setActiveSamplePresetId] = useState<string>('brooklyn-living');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  const [preferences, setPreferences] = useState<RedesignPreferences>(DEFAULT_PREFERENCES);
  const [userVerifiedPrices, setUserVerifiedPrices] = useState<Record<string, number>>({});

  // Generation & Result state
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStepIndex, setGenerationStepIndex] = useState(0);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [insufficientCreditsShown, setInsufficientCreditsShown] = useState(false);
  const [result, setResult] = useState<RedesignResult | null>(null);
  const [variationCount, setVariationCount] = useState<number>(1);

  // Server-Authoritative Credit Ledger & Pricing State
  const [accountId, setAccountId] = useState<string>('');
  const [sessionToken, setSessionToken] = useState<string>('');
  const [accountSummary, setAccountSummary] = useState<AccountBalanceSummary | null>(null);
  const [pricingConfig, setPricingConfig] = useState<PricingSystemConfig | null>(null);
  const [paymentEnv, setPaymentEnv] = useState<{
    providerMode: 'development_demo' | 'live_provider';
    providerName: string;
    liveCredentialsConfigured: boolean;
    webhookSecretConfigured: boolean;
    adminTokenConfigured: boolean;
    persistenceMode: string;
    authMode: string;
    productionChecklist: string[];
  } | null>(null);

  // Legacy client fallback state kept in sync with server balance
  const [credits, setCredits] = useState<CreditState>(() => createInitialCreditState());
  const [, setAnalyticsEvents] = useState<AnalyticsEventRecord[]>([]);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const workspaceRef = useRef<HTMLElement | null>(null);
  const resultSectionRef = useRef<HTMLDivElement | null>(null);

  const track = (
    name: AnalyticsEventName,
    metadata?: Record<string, string | number | boolean>
  ) => {
    const evt = createAnalyticsEvent(name, metadata);
    setAnalyticsEvents((prev) => [evt, ...prev.slice(0, 49)]);
  };

  // Hero & Showcase Visuals
  const heroVisuals = useMemo(() => {
    const before = renderRoomSceneToDataUrl({
      presetId: 'brooklyn-living',
      stage: 'before',
      style: 'Organic Modern',
    });
    const after = renderRoomSceneToDataUrl({
      presetId: 'brooklyn-living',
      stage: 'after',
      style: 'Organic Modern',
      noPainting: true,
      noDrilling: true,
      noHardwiring: true,
    });
    return { before, after };
  }, []);

  const showcaseTransformations = useMemo(() => {
    return [
      {
        id: 'brooklyn-living',
        badge: 'Small Rental Living Room',
        title: 'Small Rental Living Room',
        description:
          'Reuses the existing neutral sectional and coffee table while adding bouclé pillow textures, a washable flatweave rug, and warm plug-in lighting without painting or drilling.',
        style: 'Organic Modern' as DesignStyle,
        roomType: 'Living Room' as RoomType,
        beforeUrl: renderRoomSceneToDataUrl({
          presetId: 'brooklyn-living',
          stage: 'before',
          style: 'Organic Modern',
        }),
        afterUrl: renderRoomSceneToDataUrl({
          presetId: 'brooklyn-living',
          stage: 'after',
          style: 'Organic Modern',
          noPainting: true,
          noDrilling: true,
          noHardwiring: true,
        }),
        highlights: ['Existing sofa kept', 'Original walls & window preserved'],
      },
      {
        id: 'chicago-bedroom',
        badge: 'Cozy Apartment Bedroom',
        title: 'Cozy Apartment Bedroom',
        description:
          'Preserves existing flooring, doors, and built-in trim while layering oatmeal linen textiles and warm plug-in bedside lamps.',
        style: 'Japandi' as DesignStyle,
        roomType: 'Bedroom' as RoomType,
        beforeUrl: renderRoomSceneToDataUrl({
          presetId: 'chicago-bedroom',
          stage: 'before',
          style: 'Japandi',
        }),
        afterUrl: renderRoomSceneToDataUrl({
          presetId: 'chicago-bedroom',
          stage: 'after',
          style: 'Japandi',
          noPainting: true,
          noDrilling: true,
          noHardwiring: true,
        }),
        highlights: ['Zero wall drilling', 'Warm 2700K plug-in lighting'],
      },
      {
        id: 'seattle-studio',
        badge: 'Compact Studio Apartment',
        title: 'Compact Studio Apartment',
        description:
          'Defines separate sleeping and lounging zones using a low-pile area rug, multi-functional side tables, and freestanding vertical shelving without adding partitions.',
        style: 'Mid-Century Modern' as DesignStyle,
        roomType: 'Studio Apartment' as RoomType,
        beforeUrl: renderRoomSceneToDataUrl({
          presetId: 'seattle-studio',
          stage: 'before',
          style: 'Mid-Century Modern',
        }),
        afterUrl: renderRoomSceneToDataUrl({
          presetId: 'seattle-studio',
          stage: 'after',
          style: 'Mid-Century Modern',
          noPainting: true,
          noDrilling: true,
          noHardwiring: true,
        }),
        highlights: ['Visual rug zoning', 'Multi-purpose compact scale'],
      },
      {
        id: 'austin-studio',
        badge: 'Small Home Office',
        title: 'Small Home Office',
        description:
          'Prioritizes compact apartment scale, clear walking paths, and freestanding vertical storage with cord-managed plug-in task lighting.',
        style: 'Warm Minimalist' as DesignStyle,
        roomType: 'Home Office' as RoomType,
        beforeUrl: renderRoomSceneToDataUrl({
          presetId: 'austin-studio',
          stage: 'before',
          style: 'Warm Minimalist',
        }),
        afterUrl: renderRoomSceneToDataUrl({
          presetId: 'austin-studio',
          stage: 'after',
          style: 'Warm Minimalist',
          noPainting: true,
          noDrilling: true,
          noHardwiring: true,
        }),
        highlights: ['Small-space scale', 'Cord-managed plug-in task lamp'],
      },
    ];
  }, []);

  const styleCardImages = useMemo(() => {
    const map: Record<DesignStyle, string> = {
      'Organic Modern': renderStyleCardVisual('Organic Modern'),
      Japandi: renderStyleCardVisual('Japandi'),
      'Warm Minimalist': renderStyleCardVisual('Warm Minimalist'),
      'Mid-Century Modern': renderStyleCardVisual('Mid-Century Modern'),
      'Modern Classic': renderStyleCardVisual('Modern Classic'),
      'Dark Cozy': renderStyleCardVisual('Dark Cozy'),
      'Contemporary Eclectic': renderStyleCardVisual('Contemporary Eclectic'),
    };
    return map;
  }, []);

  // Load initial sample room on first mount
  useEffect(() => {
    track('homepage_viewed');
    const initialPreset = SAMPLE_ROOM_PRESETS[0];
    const dataUrl = renderRoomSceneToDataUrl({
      presetId: initialPreset.id,
      stage: 'before',
      style: initialPreset.recommendedStyle,
    });
    setUploadedPhoto({
      id: `sample-${initialPreset.id}`,
      name: `${initialPreset.title} (Sample Room)`,
      mimeType: 'image/jpeg',
      sizeBytes: 245000,
      dataUrl,
      isSample: true,
      sampleId: initialPreset.id,
    });

    fetch('/api/status')
      .then((res) => res.json())
      .then((data) => {
        if (typeof data?.apiKeyConfigured === 'boolean') {
          setAiConfigured(data.apiKeyConfigured);
        } else if (typeof data?.aiConfigured === 'boolean') {
          setAiConfigured(data.aiConfigured);
        }
      })
      .catch(() => {
        setAiConfigured(false);
      });

    // Fetch centralized server pricing config & initialize isolated server credit session
    fetch('/api/pricing/config')
      .then((res) => res.json())
      .then((data) => {
        if (data?.config) setPricingConfig(data.config);
        if (data?.paymentEnvironment) setPaymentEnv(data.paymentEnvironment);
      })
      .catch(() => {});

    const storedAcct = sessionStorage.getItem('eden_account_id') || '';
    const storedToken = sessionStorage.getItem('eden_session_token') || '';

    fetch('/api/credits/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        accountId: storedAcct || undefined,
        sessionToken: storedToken || undefined,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data?.accountId && data?.sessionToken) {
          setAccountId(data.accountId);
          setSessionToken(data.sessionToken);
          sessionStorage.setItem('eden_account_id', data.accountId);
          sessionStorage.setItem('eden_session_token', data.sessionToken);
        }
        if (data?.summary) {
          setAccountSummary(data.summary);
        }
      })
      .catch(() => {});

    const handlePopState = () => {
      const p = window.location.pathname;
      const nextRoute = p.startsWith('/pricing') ? '/pricing' : p.startsWith('/try') ? '/try' : '/';
      setCurrentRoute(nextRoute);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const refreshPricingAndBalance = async () => {
    try {
      const cfgRes = await fetch('/api/pricing/config');
      const cfgData = await cfgRes.json();
      if (cfgData?.config) setPricingConfig(cfgData.config);
      if (cfgData?.paymentEnvironment) setPaymentEnv(cfgData.paymentEnvironment);

      if (accountId && sessionToken) {
        const balRes = await fetch('/api/credits/balance', {
          headers: {
            'x-account-id': accountId,
            'x-session-token': sessionToken,
          },
        });
        if (balRes.ok) {
          const balData = await balRes.json();
          if (balData?.summary) {
            setAccountSummary(balData.summary);
          }
        }
      }
    } catch {
      // Ignore transient network errors
    }
  };

  const navigateToRoute = (route: '/' | '/pricing' | '/try', scrollTargetId?: string) => {
    setMobileMenuOpen(false);
    if (window.location.pathname !== route) {
      window.history.pushState({}, '', route);
    }
    setCurrentRoute(route);
    if (route === '/pricing') {
      track('pricing_page_viewed');
      refreshPricingAndBalance();
      if (scrollTargetId) {
        setTimeout(() => {
          document.getElementById(scrollTargetId)?.scrollIntoView({ behavior: 'smooth' });
        }, 80);
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } else if (scrollTargetId) {
      setTimeout(() => {
        document.getElementById(scrollTargetId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 80);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Step through progress messages during generation
  useEffect(() => {
    if (!isGenerating) {
      setGenerationStepIndex(0);
      return;
    }
    const timer = window.setInterval(() => {
      setGenerationStepIndex((prev) => (prev < GENERATION_STEPS.length - 1 ? prev + 1 : prev));
    }, 1100);
    return () => window.clearInterval(timer);
  }, [isGenerating]);

  const scrollToWorkspace = () => {
    setMobileMenuOpen(false);
    if (currentRoute !== '/try') {
      navigateToRoute('/try');
      return;
    }
    workspaceRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  // Jump to a section on the Try Free page (e.g. style gallery)
  const goToTry = (id?: string) => {
    setMobileMenuOpen(false);
    if (currentRoute !== '/try') {
      navigateToRoute('/try', id);
      return;
    }
    if (id) document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    else window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    if (currentRoute !== '/') {
      navigateToRoute('/', id);
      return;
    }
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Handle Sample Preset Selection
  const handleSelectSampleRoom = (preset: SampleRoomPreset) => {
    setUploadError(null);
    setGenerationError(null);
    setActiveSamplePresetId(preset.id);
    const dataUrl = renderRoomSceneToDataUrl({
      presetId: preset.id,
      stage: 'before',
      style: preset.recommendedStyle,
    });
    setUploadedPhoto({
      id: `sample-${preset.id}-${Date.now()}`,
      name: `${preset.title} (Sample Room)`,
      mimeType: 'image/jpeg',
      sizeBytes: 245000,
      dataUrl,
      isSample: true,
      sampleId: preset.id,
    });
    setPreferences((prev) => ({
      ...prev,
      roomType: preset.roomType,
      style: preset.recommendedStyle,
      isSmallSpace:
        preset.roomType === 'Studio Apartment' ||
        preset.id === 'austin-studio' ||
        preset.id === 'seattle-studio',
    }));
    track('photo_uploaded_successfully', { source: 'sample_preset', presetId: preset.id });
  };

  // Load one of the 7 real-world renter validation scenarios
  const handleLoadValidationScenario = (scenario: RenterValidationScenario) => {
    setActiveScenarioId(scenario.id);
    setUploadError(null);
    setGenerationError(null);

    const preset =
      SAMPLE_ROOM_PRESETS.find((p) => p.id === scenario.samplePresetId) || SAMPLE_ROOM_PRESETS[0];
    setActiveSamplePresetId(preset.id);
    const dataUrl = renderRoomSceneToDataUrl({
      presetId: preset.id,
      stage: 'before',
      style: scenario.preferences.style,
    });
    setUploadedPhoto({
      id: `sample-${preset.id}-${Date.now()}`,
      name: `${preset.title} (${scenario.label})`,
      mimeType: 'image/jpeg',
      sizeBytes: 245000,
      dataUrl,
      isSample: true,
      sampleId: preset.id,
    });

    setPreferences({
      ...scenario.preferences,
      rentalRules: { ...scenario.preferences.rentalRules },
      preservedArchitecture: { ...scenario.preferences.preservedArchitecture },
      identifiedFurniture: [...scenario.preferences.identifiedFurniture],
    });
    setUserVerifiedPrices(scenario.simulatedVerifiedPrices ? { ...scenario.simulatedVerifiedPrices } : {});
  };

  // Handle User File Upload with image decode verification
  const processFile = (file: File) => {
    setUploadError(null);
    setGenerationError(null);
    setActiveScenarioId(null);
    track('upload_started');
    const validation = validatePhotoUpload({
      name: file.name,
      type: file.type,
      size: file.size,
    });
    if (!validation.valid) {
      setUploadError(validation.error || 'Unsupported file format.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!dataUrl) {
        setUploadError('Could not read the selected image file. Please try another photo.');
        return;
      }
      const probeImg = new Image();
      probeImg.onload = () => {
        if (probeImg.naturalWidth < 32 || probeImg.naturalHeight < 32) {
          setUploadError('This image is too small. Please upload a clear room photo.');
          return;
        }
        setUploadedPhoto({
          id: `upload-${Date.now()}`,
          name: file.name,
          mimeType: file.type || 'image/jpeg',
          sizeBytes: file.size,
          dataUrl,
          isSample: false,
        });
        track('photo_uploaded_successfully', { source: 'user_file', sizeBytes: file.size });
      };
      probeImg.onerror = () => {
        setUploadError(
          'This file appears to be corrupted or is not a valid image. Please upload a valid JPG, PNG, or WEBP room photo.'
        );
      };
      probeImg.src = dataUrl;
    };
    reader.onerror = () => {
      setUploadError('Failed to read the selected file from your device.');
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleRemovePhoto = () => {
    setUploadedPhoto(null);
    setResult(null);
    setUploadError(null);
  };

  const handleSelectRoomType = (roomType: RoomType) => {
    setPreferences((prev) => ({
      ...prev,
      roomType,
      isSmallSpace: roomType === 'Studio Apartment' ? true : prev.isSmallSpace,
    }));
    track('design_options_selected', { option: 'roomType', value: roomType });
  };

  const handleSelectStyle = (style: DesignStyle, scrollAfterSelect = false) => {
    setPreferences((prev) => ({ ...prev, style }));
    track('design_options_selected', { option: 'style', value: style });
    if (scrollAfterSelect) {
      scrollToWorkspace();
    }
  };

  const handleSelectBudgetIntent = (budgetIntent: BudgetIntent) => {
    setPreferences((prev) => {
      let nextMax = prev.maxBudgetDollars;
      let nextTier = prev.budget;
      if (budgetIntent === 'existing_only') {
        nextMax = 0;
        nextTier = 'Under $100';
      } else if (budgetIntent === 'inspiration_no_limit') {
        nextMax = null;
        nextTier = 'Inspiration Only';
      } else if (nextMax === 0 || nextMax === null) {
        // Amount is entered manually by the person
        nextMax = null;
        nextTier = 'Under $100';
      }
      return {
        ...prev,
        budgetIntent,
        maxBudgetDollars: nextMax,
        budget: nextTier,
      };
    });
    track('design_options_selected', { option: 'budgetIntent', value: budgetIntent });
  };

  const handleSelectExistingFurnitureMode = (existingFurnitureMode: ExistingFurnitureMode) => {
    setPreferences((prev) => ({
      ...prev,
      existingFurnitureMode,
      rentalRules: {
        ...prev.rentalRules,
        keepExistingFurniture: existingFurnitureMode !== 'mostly_empty',
      },
    }));
    track('design_options_selected', {
      option: 'existingFurnitureMode',
      value: existingFurnitureMode,
    });
  };

  const handleToggleIdentifiedFurniture = (itemLabel: string) => {
    setPreferences((prev) => {
      const exists = prev.identifiedFurniture.includes(itemLabel);
      const nextList = exists
        ? prev.identifiedFurniture.filter((i) => i !== itemLabel)
        : [...prev.identifiedFurniture, itemLabel];
      return {
        ...prev,
        identifiedFurniture: nextList,
      };
    });
  };

  const handleToggleRentalRule = (key: keyof RentalRules) => {
    setPreferences((prev) => {
      const nextValue = !prev.rentalRules[key];
      const nextRules = { ...prev.rentalRules, [key]: nextValue };
      track('design_options_selected', { option: key, enabled: nextValue });
      return { ...prev, rentalRules: nextRules };
    });
  };

  const handleTogglePreservedArchitecture = (key: keyof PreservedArchitecture) => {
    setPreferences((prev) => {
      const nextValue = !prev.preservedArchitecture[key];
      return {
        ...prev,
        preservedArchitecture: {
          ...prev.preservedArchitecture,
          [key]: nextValue,
        },
      };
    });
  };

  // Update verified retailer price on a recommendation card
  const handleUpdateVerifiedPrice = (productId: string, price: number | null) => {
    setUserVerifiedPrices((prev) => {
      const next = { ...prev };
      if (price === null || Number.isNaN(price)) {
        delete next[productId];
      } else {
        next[productId] = price;
      }

      // If result is active, recalculate its budgetSummary live
      if (result) {
        const updatedSummary = calculateBudgetSummary(
          result.recommendations,
          result.preferences.maxBudgetDollars,
          result.preferences.budgetIntent,
          next
        );
        setResult({
          ...result,
          budgetSummary: updatedSummary,
        });
      }
      return next;
    });
  };

  // One-click "Revise to Fit My Budget" when selected recommendations exceed maxBudgetDollars
  const handleReviseResultToFitBudget = () => {
    if (!result) return;
    const revisedItems = reviseRecommendationsToFitBudget(
      result.recommendations,
      result.preferences.maxBudgetDollars,
      userVerifiedPrices
    );
    const updatedSummary = calculateBudgetSummary(
      revisedItems,
      result.preferences.maxBudgetDollars,
      result.preferences.budgetIntent,
      userVerifiedPrices
    );
    const updatedPlan = buildActionablePlan(result.preferences, revisedItems);
    setResult({
      ...result,
      recommendations: revisedItems,
      budgetSummary: updatedSummary,
      actionPlan: updatedPlan,
    });
  };

  // Generate Redesign Concept
  const handleGenerateDesign = async (isRegenerate = false) => {
    setUploadError(null);
    setGenerationError(null);
    setInsufficientCreditsShown(false);

    if (!uploadedPhoto) {
      setUploadError('Please upload a room photo or select a sample room before generating.');
      scrollToWorkspace();
      return;
    }

    const requiredCost = pricingConfig?.creditCosts.roomRedesignStandard ?? 1;
    const currentAvailable = accountSummary ? accountSummary.availableCredits : credits.freeTrialRemaining;

    if (currentAvailable < requiredCost) {
      setInsufficientCreditsShown(true);
      setGenerationError(
        `Insufficient credits: A room redesign requires ${requiredCost} credit${
          requiredCost === 1 ? '' : 's'
        }, and your available balance is ${currentAvailable}. Visit Pricing to add a one-time credit package.`
      );
      track('insufficient_credits_shown', {
        availableCredits: currentAvailable,
        requiredCost,
      });
      return;
    }

    const nextVariation = isRegenerate ? variationCount + 1 : 1;
    setVariationCount(nextVariation);
    setIsGenerating(true);

    const operationId = `op_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    track('generation_requested', {
      roomType: preferences.roomType,
      style: preferences.style,
      budget: preferences.budget,
      isRegenerate,
      creditCost: requiredCost,
    });

    const compiledPrompt = buildRedesignPrompt(preferences);
    const recResult = selectRecommendations(preferences, {
      userVerifiedPrices,
    });
    const complianceSummary = buildComplianceSummary(preferences.rentalRules);
    const architecturalNotes = buildArchitecturalNotes(preferences);
    const smallSpaceNotes = buildSmallSpaceNotes(preferences);
    const actionPlan = buildActionablePlan(preferences, recResult.items);

    try {
      const response = await fetch('/api/redesign', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(accountId ? { 'x-account-id': accountId } : {}),
          ...(sessionToken ? { 'x-session-token': sessionToken } : {}),
        },
        body: JSON.stringify({
          imageBase64: uploadedPhoto.dataUrl,
          mimeType: uploadedPhoto.mimeType,
          prompt: compiledPrompt,
          preferences,
          preferDemoMode: preferDemoMode || !aiConfigured,
          operationId,
          accountId: accountId || undefined,
          sessionToken: sessionToken || undefined,
        }),
      });

      const payload = await response.json().catch(() => null);

      if (payload?.accountSummary) {
        setAccountSummary(payload.accountSummary);
      }

      if (response.status === 402 || payload?.code === 'INSUFFICIENT_CREDITS') {
        setInsufficientCreditsShown(true);
        setGenerationError(
          payload?.error ||
            'Your credit balance is 0. Visit the Pricing page to add design credits.'
        );
        track('insufficient_credits_shown', { status: 402 });
        setIsGenerating(false);
        return;
      }

      if (!response.ok && !payload?.fallbackDemo) {
        const message = formatApiErrorMessage(response.status, payload?.error);
        setGenerationError(message);
        track('generation_failed', {
          status: response.status,
          creditRefunded: Boolean(payload?.creditRefunded),
        });
        setIsGenerating(false);
        return;
      }

      let afterImageUrl = '';
      let mode: 'live_ai' | 'demo_fallback' = 'demo_fallback';
      let modeReason =
        payload?.modeReason ||
        'Generated in Demo Concept Mode using Eden Canvas photographic lighting & color grading.';

      if (
        payload &&
        payload.mode === 'live_ai' &&
        (payload.generatedImageDataUrl || payload.redesignedImageDataUrl)
      ) {
        afterImageUrl = payload.generatedImageDataUrl || payload.redesignedImageDataUrl;
        mode = 'live_ai';
        modeReason = payload.modeReason || 'Generated live via Gemini image transformation.';
      } else {
        afterImageUrl = await createDemoTransformationFromUpload(
          uploadedPhoto.dataUrl,
          preferences,
          nextVariation
        );
        mode = 'demo_fallback';
      }

      setCredits((prev) => consumeDesignCredit(prev));
      track('credits_used', {
        amount: requiredCost,
        balanceAfter: payload?.accountSummary?.availableCredits ?? Math.max(0, currentAvailable - requiredCost),
      });

      const newResult: RedesignResult = {
        id: `eden-result-${Date.now()}`,
        variationNumber: nextVariation,
        createdAt: new Date().toISOString(),
        mode,
        modeReason,
        originalImageDataUrl: uploadedPhoto.dataUrl,
        redesignedImageDataUrl: afterImageUrl,
        preferences: {
          ...preferences,
          rentalRules: { ...preferences.rentalRules },
          preservedArchitecture: { ...preferences.preservedArchitecture },
          identifiedFurniture: [...preferences.identifiedFurniture],
        },
        promptUsed: compiledPrompt,
        serverConfirmedPrompt: payload?.receivedPrompt || compiledPrompt,
        architecturalNotes,
        renterComplianceNotes: complianceSummary,
        smallSpaceNotes,
        designSummary: `${preferences.style} ${preferences.roomType} concept tailored for ${
          preferences.maxBudgetDollars !== null
            ? `a $${preferences.maxBudgetDollars} max budget`
            : preferences.budget
        }.`,
        actionPlan,
        recommendations: recResult.items,
        budgetSummary: recResult.budgetSummary,
        budgetGuidance: recResult.budgetGuidance,
      };

      setResult(newResult);
      track('generation_completed', { mode, style: preferences.style });
      setTimeout(() => {
        resultSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 120);
    } catch (err) {
      const message = formatApiErrorMessage(
        'NETWORK_ERROR',
        err instanceof Error ? err.message : undefined
      );
      setGenerationError(message);
      track('generation_failed', { reason: 'network_exception' });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadResult = () => {
    if (!result) return;
    const link = document.createElement('a');
    link.href = result.redesignedImageDataUrl;
    const styleSlug = result.preferences.style.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const suffix = result.mode === 'demo_fallback' ? 'demo-concept' : 'ai-redesign';
    link.download = `eden-canvas-${styleSlug}-${suffix}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    track('result_downloaded', { style: result.preferences.style, mode: result.mode });
  };

  const handleStartOver = () => {
    setResult(null);
    setGenerationError(null);
    setInsufficientCreditsShown(false);
    setUploadError(null);
    setActiveScenarioId(null);
    setUserVerifiedPrices({});
    setPreferences(DEFAULT_PREFERENCES);
    handleSelectSampleRoom(SAMPLE_ROOM_PRESETS[0]);
    scrollToWorkspace();
  };

  const handleResetCredits = async () => {
    setCredits(createInitialCreditState());
    setGenerationError(null);
    setInsufficientCreditsShown(false);
    try {
      const res = await fetch('/api/credits/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (data?.accountId && data?.sessionToken) {
        setAccountId(data.accountId);
        setSessionToken(data.sessionToken);
        sessionStorage.setItem('eden_account_id', data.accountId);
        sessionStorage.setItem('eden_session_token', data.sessionToken);
      }
      if (data?.summary) {
        setAccountSummary(data.summary);
      }
    } catch {
      // ignore
    }
  };

  // Standalone homepage preview recommendations based on current preferences
  const previewRecResult = useMemo(() => {
    return selectRecommendations(preferences, { userVerifiedPrices });
  }, [preferences, userVerifiedPrices]);

  const previewFreeSteps = useMemo(() => {
    return buildActionablePlan(preferences, previewRecResult.items).filter(
      (step) => step.costTier === 'free'
    );
  }, [preferences, previewRecResult.items]);

  const handleReviseHomepagePreviewBudget = () => {
    if (preferences.maxBudgetDollars === null) return;
    const revised = reviseRecommendationsToFitBudget(
      previewRecResult.items,
      preferences.maxBudgetDollars,
      userVerifiedPrices
    );
    if (revised.length === 0) {
      handleSelectBudgetIntent('existing_only');
    } else {
      setPreferences((prev) => ({
        ...prev,
        budgetIntent: 'few_affordable',
        budget: 'Under $100',
      }));
    }
  };

  const primaryRentalRules = useMemo(
    () => RENTAL_RULE_DEFINITIONS.filter((r) => r.isPrimaryToggle),
    []
  );

  return (
    <div className="min-h-screen bg-[#FFFFFF] text-[#1C2420] flex flex-col selection:bg-[#D9E7DC] selection:text-[#1C2420]">
      {/* 4. SLIM WHITE NAVIGATION BAR */}
      <header className="sticky top-0 z-40 bg-[#FFFFFF]/95 backdrop-blur-md border-b border-[#E8E1D6]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          {/* Left: Eden Canvas wordmark with minimal symbol */}
          <button
            type="button"
            onClick={() => navigateToRoute('/')}
            className="flex items-center gap-2.5 group focus:outline-none text-left cursor-pointer shrink-0 whitespace-nowrap"
            aria-label="Eden Canvas Home"
          >
            <img
              src="/images/eden-canvas-logo.png"
              alt="Eden Canvas"
              width={1200}
              height={192}
              className="h-7 sm:h-8 w-auto select-none group-hover:opacity-80 transition-opacity"
              draggable={false}
            />
          </button>

          {/* Center: 4 Clean Navigation Links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#667067]">
            <button
              type="button"
              onClick={() => scrollToSection('how-it-works')}
              className="hover:text-[#1C2420] transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              How It Works
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('showcase')}
              className="hover:text-[#1C2420] transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Examples
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('renter-friendly')}
              className="hover:text-[#1C2420] transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Renter-Friendly Design
            </button>
            <button
              type="button"
              onClick={() => navigateToRoute('/pricing')}
              className={`transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                currentRoute === '/pricing'
                  ? 'text-[#1F4D3D] font-semibold underline underline-offset-4'
                  : 'hover:text-[#1C2420]'
              }`}
            >
              Pricing
            </button>
          </nav>

          {/* Right: Credit Balance Indicator, Log In, and Prominent Green CTA "Design My Room" */}
          <div className="hidden md:flex items-center gap-4 shrink-0">
            <button
              type="button"
              data-testid="header-credit-balance"
              onClick={() => navigateToRoute('/pricing', 'credit-ledger-section')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-[#667067] hover:text-[#1C2420] transition-colors cursor-pointer whitespace-nowrap"
              title="View your credit ledger and packages"
            >
              <Coins className="w-3.5 h-3.5 text-[#1F4D3D]" />
              <span>
                {accountSummary?.availableCredits ?? credits.freeTrialRemaining} credit
                {(accountSummary?.availableCredits ?? credits.freeTrialRemaining) === 1 ? '' : 's'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setLegalModal('login')}
              className="text-sm font-medium text-[#667067] hover:text-[#1C2420] transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Log In
            </button>

            <button
              type="button"
              onClick={scrollToWorkspace}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#1F4D3D] text-[#FFFFFF] text-sm font-semibold hover:bg-[#153A2E] transition-colors shadow-2xs cursor-pointer whitespace-nowrap shrink-0"
            >
              <span>Try Free</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              type="button"
              onClick={() => navigateToRoute('/pricing')}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#FAF7F2] border border-[#E8E1D6] text-xs font-semibold text-[#1C2420]"
            >
              <Coins className="w-3.5 h-3.5 text-[#1F4D3D]" />
              <span>{accountSummary?.availableCredits ?? credits.freeTrialRemaining}</span>
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              className="inline-flex items-center justify-center p-2.5 rounded-xl border border-[#E8E1D6] text-[#1C2420] hover:bg-[#FAF7F2] transition-colors"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Collapsible Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-[#FFFFFF] border-b border-[#E8E1D6] px-4 pt-3 pb-5 space-y-2 shadow-lg">
            <button
              type="button"
              onClick={() => scrollToSection('how-it-works')}
              className="block w-full text-left py-2.5 px-3 rounded-lg text-sm font-medium text-[#1C2420] hover:bg-[#FAF7F2]"
            >
              How It Works
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('showcase')}
              className="block w-full text-left py-2.5 px-3 rounded-lg text-sm font-medium text-[#1C2420] hover:bg-[#FAF7F2]"
            >
              Examples
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('renter-friendly')}
              className="block w-full text-left py-2.5 px-3 rounded-lg text-sm font-medium text-[#1C2420] hover:bg-[#FAF7F2]"
            >
              Renter-Friendly Design
            </button>
            <button
              type="button"
              onClick={() => navigateToRoute('/pricing')}
              className="block w-full text-left py-2.5 px-3 rounded-lg text-sm font-semibold text-[#1F4D3D] hover:bg-[#FAF7F2]"
            >
              Pricing ({accountSummary?.availableCredits ?? credits.freeTrialRemaining} credits remaining)
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                setLegalModal('login');
              }}
              className="block w-full text-left py-2.5 px-3 rounded-lg text-sm font-medium text-[#667067] hover:bg-[#FAF7F2]"
            >
              Log In
            </button>
            <div className="pt-2">
              <button
                type="button"
                onClick={scrollToWorkspace}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#1F4D3D] text-[#FFFFFF] text-sm font-semibold hover:bg-[#153A2E] transition-colors"
              >
                <span>Try Free</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </header>

      <main id="top" className="flex-1">
        {currentRoute === '/pricing' ? (
          <PricingPage
            pricingConfig={pricingConfig}
            paymentEnv={paymentEnv}
            accountSummary={accountSummary}
            accountId={accountId}
            sessionToken={sessionToken}
            onStartFreeDesign={() => navigateToRoute('/try')}
            onRefreshPricingAndBalance={refreshPricingAndBalance}
            onTrackEvent={track}
            activePolicyDoc={activePolicyDoc}
            onOpenPolicyDoc={setActivePolicyDoc}
          />
        ) : currentRoute === '/try' ? (
          <>
            {/* TRY FREE — page intro */}
            <section className="bg-[linear-gradient(180deg,#FAF7F2_0%,#FAF7F2_100%)] pt-8 sm:pt-10 border-b border-[#E8E1D6]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs sm:text-sm font-medium text-[#667067]">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#D9E7DC] text-[#1F4D3D] font-semibold">
                    <Sparkles className="w-3.5 h-3.5" />
                    Free trial
                  </span>
                  <span>No card required</span>
                  <span>1 credit = 1 room redesign</span>
                </div>
                <button
                  type="button"
                  onClick={() => navigateToRoute('/pricing', 'credit-ledger-section')}
                  className="inline-flex items-center gap-2 text-sm font-semibold text-[#1F4D3D] hover:underline cursor-pointer self-start sm:self-auto"
                >
                  <Coins className="w-4 h-4" />
                  {accountSummary?.availableCredits ?? credits.freeTrialRemaining} credits remaining
                </button>
              </div>
            </section>

            {/* 6. MAIN ROOM UPLOAD EXPERIENCE (#studio) */}
            <section
              id="studio"
              ref={workspaceRef}
              className="py-16 sm:py-24 bg-[#FAF7F2] scroll-mt-16 border-b border-[#E8E1D6]"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
                  <div className="max-w-2xl">
                    <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1F4D3D]">
                      Interactive Design Studio
                    </span>
                    <h2 className="text-3xl sm:text-4xl font-semibold text-[#1C2420] mt-2 tracking-tight">
                      Start With Your Room
                    </h2>
                    <p className="text-base sm:text-lg text-[#667067] mt-2">
                      Upload a photo and explore what your space could become.
                    </p>
                  </div>

                  {/* Real-World Renter Scenario Quick Loader */}
                  <div className="bg-[#FFFFFF] p-3.5 rounded-2xl border border-[#E8E1D6] w-full lg:max-w-md max-h-80 overflow-y-auto">
                    <div className="text-[11px] font-semibold uppercase tracking-wider text-[#1F4D3D] mb-2">
                      Quick Renter Scenario Presets (choose one):
                    </div>
                    <ChoiceList
                      mode="single"
                      dense
                      ariaLabel="Quick renter scenario presets"
                      items={RENTER_VALIDATION_SCENARIOS.map((sc) => ({
                        id: sc.id,
                        label: sc.label,
                        description: sc.shortDescription,
                      }))}
                      selected={activeScenarioId ? [activeScenarioId] : []}
                      onToggle={(id) => {
                        const sc = RENTER_VALIDATION_SCENARIOS.find((x) => x.id === id);
                        if (sc) handleLoadValidationScenario(sc);
                      }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  {/* Left Column: Upload, Room Type + Small-Space, What I Already Own, Keep What Cannot Be Changed */}
                  <div className="lg:col-span-5 space-y-6">
                    {/* Step 1 — Upload Your Room */}
                    <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2.5">
                          <span className="w-6 h-6 rounded-full bg-[#D9E7DC] text-[#1F4D3D] text-xs font-semibold flex items-center justify-center">
                            1
                          </span>
                          <h3 className="text-lg font-semibold text-[#1C2420]">Upload Your Room</h3>
                        </div>
                        <span className="text-xs text-[#667067]">JPG, PNG, or WEBP · Max 10 MB</span>
                      </div>

                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        onChange={handleFileChange}
                        className="hidden"
                        aria-label="Upload room photo"
                      />

                      {uploadedPhoto ? (
                        <div className="space-y-4">
                          <div className="relative rounded-xl overflow-hidden border border-[#E8E1D6] bg-[#FAF7F2] aspect-[16/10]">
                            <img
                              src={uploadedPhoto.dataUrl}
                              alt={uploadedPhoto.name}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute top-3 left-3 bg-[#1C2420]/80 backdrop-blur-xs text-[#FFFFFF] text-[11px] font-medium px-2.5 py-1 rounded-md">
                              {uploadedPhoto.isSample ? 'Sample Rental Room' : 'Your Uploaded Room'}
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <p className="text-xs font-medium text-[#1C2420] truncate max-w-[200px]">
                              {uploadedPhoto.name}
                            </p>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => fileInputRef.current?.click()}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F3EDE2] hover:bg-[#D9E7DC]/70 text-xs font-semibold text-[#1C2420] border border-[#E8E1D6] transition-colors cursor-pointer"
                              >
                                <Upload className="w-3.5 h-3.5 text-[#1F4D3D]" />
                                <span>Replace Photo</span>
                              </button>
                              <button
                                type="button"
                                onClick={handleRemovePhoto}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#E8E1D6] hover:bg-[#FAF7F2] text-xs text-[#667067] transition-colors cursor-pointer"
                              >
                                <X className="w-3.5 h-3.5" />
                                <span>Remove</span>
                              </button>
                            </div>
                          </div>

                          <div
                            onDragOver={(e) => {
                              e.preventDefault();
                              setIsDraggingOver(true);
                            }}
                            onDragLeave={() => setIsDraggingOver(false)}
                            onDrop={handleDrop}
                            onClick={() => fileInputRef.current?.click()}
                            className={`rounded-xl border-2 border-dashed p-3.5 text-center transition-colors cursor-pointer ${
                              isDraggingOver
                                ? 'border-[#1F4D3D] bg-[#D9E7DC]/35'
                                : 'border-[#E8E1D6] hover:border-[#1F4D3D]/60 bg-[#FAF7F2]'
                            }`}
                          >
                            <p className="text-xs font-medium text-[#1C2420]">
                              Drag and drop a new room photo here or click{' '}
                              <span className="underline text-[#1F4D3D]">Browse Files</span>
                            </p>
                          </div>
                        </div>
                      ) : (
                        <div
                          onDragOver={(e) => {
                            e.preventDefault();
                            setIsDraggingOver(true);
                          }}
                          onDragLeave={() => setIsDraggingOver(false)}
                          onDrop={handleDrop}
                          onClick={() => fileInputRef.current?.click()}
                          className={`rounded-xl border-2 border-dashed p-8 text-center transition-all cursor-pointer ${
                            isDraggingOver
                              ? 'border-[#1F4D3D] bg-[#D9E7DC]/35'
                              : 'border-[#E8E1D6] hover:border-[#1F4D3D] bg-[#FAF7F2]'
                          }`}
                        >
                          <div className="w-12 h-12 rounded-2xl bg-[#D9E7DC] text-[#1F4D3D] flex items-center justify-center mx-auto mb-3">
                            <Upload className="w-6 h-6" />
                          </div>
                          <p className="text-base font-semibold text-[#1C2420]">
                            Drop your room photo here
                          </p>
                          <p className="text-xs text-[#667067] mt-1 mb-4">
                            Supports JPG, PNG, or WEBP up to 10 MB
                          </p>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              fileInputRef.current?.click();
                            }}
                            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#FFFFFF] border border-[#E8E1D6] text-xs font-semibold text-[#1C2420] hover:bg-[#F3EDE2] transition-colors"
                          >
                            <ImageIcon className="w-3.5 h-3.5 text-[#1F4D3D]" />
                            <span>Browse Files</span>
                          </button>
                        </div>
                      )}

                      {uploadError && (
                        <div
                          role="alert"
                          className="mt-3 p-3 rounded-xl bg-[#EFE5D6]/70 border border-[#C2623F] text-xs text-[#1C2420] flex items-start gap-2"
                        >
                          <AlertCircle className="w-4 h-4 text-[#C2623F] shrink-0 mt-0.5" />
                          <span>{uploadError}</span>
                        </div>
                      )}

                      {/* Quick Sample Rooms */}
                      <div className="mt-5 pt-4 border-t border-[#E8E1D6]">
                        <p className="text-xs font-medium text-[#667067] mb-2.5">
                          Or try a sample rental room photo:
                        </p>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {SAMPLE_ROOM_PRESETS.map((preset) => {
                            const isSelectedSample =
                              uploadedPhoto?.isSample && activeSamplePresetId === preset.id;
                            return (
                              <button
                                key={preset.id}
                                type="button"
                                onClick={() => handleSelectSampleRoom(preset)}
                                className={`text-left p-2 rounded-xl border text-xs transition-all cursor-pointer ${
                                  isSelectedSample
                                    ? 'border-[#1F4D3D] bg-[#D9E7DC]/45 text-[#1C2420] font-semibold'
                                    : 'border-[#E8E1D6] bg-[#FAF7F2] text-[#667067] hover:border-[#1F4D3D]/40'
                                }`}
                              >
                                <div className="truncate text-[11px] font-medium text-[#1C2420]">
                                  {preset.roomType}
                                </div>
                                <div className="truncate text-[10px] text-[#667067]">
                                  {preset.recommendedStyle}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    {/* Step 2 — Room Type Selector & Small-Space Mode */}
                    <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                      <div className="flex items-center gap-2.5 mb-4">
                        <span className="w-6 h-6 rounded-full bg-[#D9E7DC] text-[#1F4D3D] text-xs font-semibold flex items-center justify-center">
                          2
                        </span>
                        <h3 className="text-lg font-semibold text-[#1C2420]">Select Room Type</h3>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {ROOM_TYPES.map((room) => {
                          const selected = preferences.roomType === room.id;
                          return (
                            <button
                              key={room.id}
                              type="button"
                              onClick={() => handleSelectRoomType(room.id)}
                              aria-pressed={selected}
                              className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                                selected
                                  ? 'bg-[#1F4D3D] text-[#FFFFFF] border-[#1F4D3D] shadow-2xs'
                                  : 'bg-[#FAF7F2] text-[#1C2420] border-[#E8E1D6] hover:border-[#1F4D3D]/50'
                              }`}
                            >
                              <div>
                                <div className="text-sm font-semibold">{room.label}</div>
                                <div
                                  className={`text-[11px] mt-0.5 line-clamp-1 ${
                                    selected ? 'text-[#D9E7DC]' : 'text-[#667067]'
                                  }`}
                                >
                                  {room.description}
                                </div>
                              </div>
                              {selected && <Check className="w-4 h-4 shrink-0 ml-2" />}
                            </button>
                          );
                        })}
                      </div>

                      {/* Small-Space Solutions Toggle */}
                      <div className="mt-4 pt-4 border-t border-[#E8E1D6]">
                        <button
                          type="button"
                          role="switch"
                          aria-checked={
                            preferences.isSmallSpace || preferences.roomType === 'Studio Apartment'
                          }
                          onClick={() =>
                            setPreferences((prev) => ({
                              ...prev,
                              isSmallSpace: !prev.isSmallSpace,
                            }))
                          }
                          className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer flex items-start justify-between gap-3 ${
                            preferences.isSmallSpace || preferences.roomType === 'Studio Apartment'
                              ? 'bg-[#1F4D3D] text-[#FFFFFF] border-[#1F4D3D]'
                              : 'bg-[#FAF7F2] text-[#1C2420] border-[#E8E1D6]'
                          }`}
                        >
                          <div className="flex items-start gap-2.5">
                            <Maximize2 className="w-4 h-4 shrink-0 mt-0.5" />
                            <div>
                              <div className="text-xs sm:text-sm font-semibold">
                                Small-Space &amp; Studio Apartment Mode
                              </div>
                              <div
                                className={`text-[11px] mt-0.5 ${
                                  preferences.isSmallSpace ||
                                  preferences.roomType === 'Studio Apartment'
                                    ? 'text-[#D9E7DC]'
                                    : 'text-[#667067]'
                                }`}
                              >
                                Prioritize compact scale, multi-purpose furniture, clear walking paths, and no-drill vertical storage without distorting room proportions.
                              </div>
                            </div>
                          </div>
                          <span className="text-[11px] font-semibold shrink-0">
                            {preferences.isSmallSpace || preferences.roomType === 'Studio Apartment'
                              ? 'Active'
                              : 'Off'}
                          </span>
                        </button>
                        <p className="mt-2 text-[11px] text-[#667067]">
                          Note: Exact furniture fit cannot be guaranteed from a photo alone without reliable physical room measurements.
                        </p>
                      </div>
                    </div>

                    {/* "What I Already Own?" — Existing-Furniture Preferences */}
                    <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                      <div className="flex items-center gap-2.5 mb-2">
                        <Sofa className="w-5 h-5 text-[#1F4D3D]" />
                        <h3 className="text-lg font-semibold text-[#1C2420]">What I Already Own?</h3>
                      </div>
                      <p className="text-xs text-[#667067] mb-4 leading-relaxed">
                        Tell us how much of your current furniture to keep. Our design instructions and action plan prioritize reusing existing items before recommending new purchases.
                      </p>

                      <ChoiceList
                        mode="single"
                        ariaLabel="How much existing furniture to keep"
                        items={EXISTING_FURNITURE_MODES.map((m) => ({ id: m.id, label: m.label, description: m.description }))}
                        selected={[preferences.existingFurnitureMode]}
                        onToggle={(id) => handleSelectExistingFurnitureMode(id as ExistingFurnitureMode)}
                      />

                      {preferences.existingFurnitureMode !== 'mostly_empty' && (
                        <div className="mt-4 pt-4 border-t border-[#E8E1D6] space-y-3">
                          <div>
                            <p className="text-xs font-semibold text-[#1C2420]">
                              Identify important furniture in your photo to keep/reuse (select all that apply):
                            </p>
                            <p className="text-[11px] text-[#667067] mt-0.5">
                              AI cannot recognize every object in a photo perfectly—selecting key items ensures your plan builds around them.
                            </p>
                          </div>

                          <ChoiceList
                            mode="multi"
                            dense
                            twoColumns
                            ariaLabel="Furniture to keep or reuse"
                            items={IDENTIFIABLE_FURNITURE_CHIPS.map((chip) => ({ id: chip, label: chip }))}
                            selected={preferences.identifiedFurniture}
                            onToggle={handleToggleIdentifiedFurniture}
                          />

                          <div>
                            <label
                              htmlFor="furniture-notes"
                              className="block text-[11px] font-medium text-[#667067] mb-1"
                            >
                              Optional details about your existing pieces (color, position, size):
                            </label>
                            <input
                              id="furniture-notes"
                              type="text"
                              maxLength={160}
                              value={preferences.identifiedFurnitureNotes}
                              onChange={(e) =>
                                setPreferences((prev) => ({
                                  ...prev,
                                  identifiedFurnitureNotes: e.target.value,
                                }))
                              }
                              placeholder="e.g., Keep my beige L-shaped sofa and oak coffee table"
                              className="w-full rounded-xl bg-[#FAF7F2] border border-[#E8E1D6] px-3 py-2 text-xs text-[#1C2420]"
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* "Keep What Cannot Be Changed" — Architectural Preservation */}
                    <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Lock className="w-4 h-4 text-[#1F4D3D]" />
                          <h3 className="text-lg font-semibold text-[#1C2420]">
                            Keep What Cannot Be Changed
                          </h3>
                        </div>
                        <span className="text-[11px] font-medium text-[#1F4D3D]">
                          Fixed Architecture
                        </span>
                      </div>
                      <p className="text-xs text-[#667067] mb-3.5 leading-relaxed">
                        Select all fixed apartment features in your photo that must remain unchanged:
                      </p>

                      <ChoiceList
                        mode="multi"
                        dense
                        ariaLabel="Fixed architecture to preserve"
                        items={PRESERVED_ARCHITECTURE_DEFINITIONS.map((feat) => ({
                          id: feat.key,
                          label: feat.label,
                          description: feat.explanation,
                        }))}
                        selected={PRESERVED_ARCHITECTURE_DEFINITIONS.filter((f) => preferences.preservedArchitecture[f.key]).map((f) => f.key)}
                        onToggle={(id) => handleTogglePreservedArchitecture(id as keyof PreservedArchitecture)}
                      />

                      <p className="mt-3 text-[11px] text-[#667067] leading-relaxed">
                        Note: These preservation preferences are passed directly into the image-generation request; however, AI-generated concepts may still alter some surface or architectural details.
                      </p>
                    </div>
                  </div>

                  {/* Right Column: Design Style Selector, Budget Selector, Renter Restrictions + Primary Generate CTA */}
                  <div className="lg:col-span-7 space-y-6">
                    {/* Step 3 — Design Style Selector (All 7 Styles) */}
                    <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2.5">
                          <span className="w-6 h-6 rounded-full bg-[#D9E7DC] text-[#1F4D3D] text-xs font-semibold flex items-center justify-center">
                            3
                          </span>
                          <h3 className="text-lg font-semibold text-[#1C2420]">Choose Design Style <span className="text-xs font-medium text-[#667067]">(pick one)</span></h3>
                        </div>
                        <span className="text-xs font-semibold text-[#1F4D3D]">
                          Selected: {preferences.style}
                        </span>
                      </div>

                      <ChoiceList
                        mode="single"
                        ariaLabel="Design style"
                        items={DESIGN_STYLES.map((st) => ({
                          id: st.id,
                          label: st.label,
                          description: st.tagline,
                          image: styleCardImages[st.id],
                          swatches: st.swatches,
                        }))}
                        selected={[preferences.style]}
                        onToggle={(id) => handleSelectStyle(id as DesignStyle)}
                      />
                    </div>

                    {/* Step 4 — Budget Selector & Spending Plan */}
                    <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6] space-y-5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <span className="w-6 h-6 rounded-full bg-[#D9E7DC] text-[#1F4D3D] text-xs font-semibold flex items-center justify-center">
                            4
                          </span>
                          <h3 className="text-lg font-semibold text-[#1C2420]">Set Your Budget</h3>
                        </div>
                        <span className="text-xs font-semibold text-[#1F4D3D]">
                          {preferences.maxBudgetDollars !== null
                            ? `$${preferences.maxBudgetDollars} Max Cap`
                            : 'Inspiration Only (No Cap)'}
                        </span>
                      </div>

                      {/* Spending Intent Options */}
                      <div>
                        <p className="text-xs font-semibold text-[#1C2420] mb-2">
                          How would you like to approach spending?
                        </p>
                        <ChoiceList
                          mode="single"
                          ariaLabel="Spending approach"
                          items={BUDGET_INTENT_OPTIONS.map((i) => ({ id: i.id, label: i.label, description: i.description }))}
                          selected={[preferences.budgetIntent]}
                          onToggle={(id) => handleSelectBudgetIntent(id as BudgetIntent)}
                        />
                      </div>

                      {/* Manual budget entry only */}
                      <div className="pt-4 border-t border-[#E8E1D6]">
                        <label htmlFor="custom-max-budget" className="block text-xs font-semibold text-[#1C2420] mb-2">
                          Your maximum budget (type an amount)
                        </label>
                        <div className="flex items-center gap-2 max-w-xs">
                          <div className="relative flex-1">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-[#667067]">$</span>
                            <input
                              id="custom-max-budget"
                              type="number"
                              inputMode="numeric"
                              min={0}
                              max={100000}
                              step={1}
                              placeholder="e.g. 250"
                              value={preferences.maxBudgetDollars !== null ? preferences.maxBudgetDollars : ''}
                              onChange={(e) => {
                                const raw = e.target.value.trim();
                                if (raw === '') {
                                  setPreferences((prev) => ({
                                    ...prev,
                                    maxBudgetDollars: null,
                                    budget: 'Inspiration Only',
                                    budgetIntent: 'inspiration_no_limit',
                                  }));
                                  return;
                                }
                                const num = Math.max(0, Math.floor(Number(raw)));
                                if (!Number.isFinite(num)) return;
                                setPreferences((prev) => ({
                                  ...prev,
                                  maxBudgetDollars: num,
                                  budget:
                                    num <= 100
                                      ? 'Under $100'
                                      : num <= 300
                                      ? '$100–$300'
                                      : num <= 500
                                      ? '$300–$500'
                                      : '$500–$1,000',
                                  budgetIntent:
                                    num === 0
                                      ? 'existing_only'
                                      : prev.budgetIntent === 'existing_only' || prev.budgetIntent === 'inspiration_no_limit'
                                      ? 'few_affordable'
                                      : prev.budgetIntent,
                                }));
                              }}
                              className="w-full rounded-xl bg-[#FAF7F2] border border-[#E8E1D6] pl-7 pr-3 py-2.5 text-sm font-semibold text-[#1C2420] focus:outline-none focus:ring-2 focus:ring-[#1F4D3D]/40"
                            />
                          </div>
                          <span className="text-xs text-[#667067] shrink-0">USD</span>
                        </div>
                        <p className="mt-2 text-[11px] text-[#667067]">
                          Enter 0 to use only what you own. Leave empty for no limit (inspiration only).
                        </p>
                      </div>
                    </div>

                    {/* Step 5 — Renter-Friendly Restrictions + Progressive Disclosure + Generate CTA */}
                    <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2.5">
                          <span className="w-6 h-6 rounded-full bg-[#D9E7DC] text-[#1F4D3D] text-xs font-semibold flex items-center justify-center">
                            5
                          </span>
                          <h3 className="text-lg font-semibold text-[#1C2420]">
                            Renter-Friendly Restrictions
                          </h3>
                        </div>
                        <span className="text-xs text-[#1F4D3D] font-medium">
                          Select all that apply
                        </span>
                      </div>

                      <ChoiceList
                        mode="multi"
                        ariaLabel="Renter-friendly restrictions"
                        items={primaryRentalRules.map((rule) => ({ id: rule.key, label: rule.label, description: rule.explanation }))}
                        selected={primaryRentalRules.filter((r) => preferences.rentalRules[r.key]).map((r) => r.key)}
                        onToggle={(id) => handleToggleRentalRule(id as keyof RentalRules)}
                      />

                      {/* Mandatory Rental Risk & Lease Notice */}
                      <div className="mt-4 p-3.5 rounded-xl bg-[#F3EDE2] border border-[#E8E1D6] text-xs text-[#667067] leading-relaxed">
                        <strong className="text-[#1C2420]">Rental Risk &amp; Lease Notice:</strong>{' '}
                        Even removable or peel-and-stick adhesive products may still damage certain
                        paint, wallpaper, or drywall finishes upon removal, and residential lease
                        terms vary. Eden Canvas does not guarantee that any product or installation
                        is damage-free or landlord-approved.
                      </div>

                      {/* Progressive Disclosure for Advanced Options */}
                      <div className="mt-4 pt-3 border-t border-[#E8E1D6]">
                        <button
                          type="button"
                          onClick={() => setShowAdvancedControls((prev) => !prev)}
                          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F4D3D] hover:underline cursor-pointer"
                        >
                          <Sliders className="w-3.5 h-3.5" />
                          <span>
                            {showAdvancedControls
                              ? 'Hide advanced options (room goal, custom note & AI prompt preview)'
                              : 'Advanced options (improvement goal, custom note, AI prompt preview)'}
                          </span>
                          {showAdvancedControls ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </button>

                        {showAdvancedControls && (
                          <div className="mt-4 space-y-4 bg-[#FAF7F2] p-4 rounded-xl border border-[#E8E1D6]">
                            <div>
                              <label
                                htmlFor="improvement-goal"
                                className="block text-xs font-semibold text-[#1C2420] mb-1.5"
                              >
                                Primary Improvement Goal
                              </label>
                              <select
                                id="improvement-goal"
                                value={preferences.improvementGoal}
                                onChange={(e) =>
                                  setPreferences((prev) => ({
                                    ...prev,
                                    improvementGoal: e.target.value,
                                  }))
                                }
                                className="w-full rounded-xl bg-[#FFFFFF] border border-[#E8E1D6] px-3 py-2 text-xs text-[#1C2420]"
                              >
                                {IMPROVEMENT_GOALS.map((g) => (
                                  <option key={g} value={g}>
                                    {g}
                                  </option>
                                ))}
                              </select>
                            </div>

                            <div>
                              <label
                                htmlFor="custom-note"
                                className="block text-xs font-semibold text-[#1C2420] mb-1.5"
                              >
                                Optional Note
                              </label>
                              <input
                                id="custom-note"
                                type="text"
                                maxLength={220}
                                value={preferences.customInstruction}
                                onChange={(e) =>
                                  setPreferences((prev) => ({
                                    ...prev,
                                    customInstruction: e.target.value,
                                  }))
                                }
                                placeholder="Optional personal note for your room..."
                                className="w-full rounded-xl bg-[#FFFFFF] border border-[#E8E1D6] px-3 py-2 text-xs text-[#1C2420]"
                              />
                            </div>

                            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#E8E1D6] text-xs">
                              <label className="inline-flex items-center gap-2 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={preferDemoMode}
                                  onChange={(e) => setPreferDemoMode(e.target.checked)}
                                  className="rounded border-[#E8E1D6] text-[#1F4D3D] focus:ring-[#1F4D3D]"
                                />
                                <span className="text-[#1C2420] font-medium">
                                  Force instant Demo Concept Mode
                                </span>
                              </label>

                              <button
                                type="button"
                                onClick={() => setShowPromptInspector((prev) => !prev)}
                                className="text-xs font-semibold text-[#1F4D3D] underline cursor-pointer"
                              >
                                {showPromptInspector ? 'Hide AI Prompt' : 'Inspect AI Prompt'}
                              </button>
                            </div>

                            {showPromptInspector && (
                              <pre className="p-3 rounded-xl bg-[#1C2420] text-[#FAF7F2] font-mono text-[11px] whitespace-pre-wrap leading-relaxed max-h-56 overflow-y-auto">
                                {buildRedesignPrompt(preferences)}
                              </pre>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Primary Generate Button: "Generate My Design" */}
                      <div className="mt-6">
                        <div className="mb-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-[#667067] bg-[#FAF7F2] px-3.5 py-2 rounded-xl border border-[#E8E1D6]">
                          <span className="flex items-center gap-1.5">
                            <Coins className="w-3.5 h-3.5 text-[#1F4D3D]" />
                            <span>
                              Cost:{' '}
                              <strong className="text-[#1C2420]">
                                {pricingConfig?.creditCosts.roomRedesignStandard ?? 1} credit
                                {(pricingConfig?.creditCosts.roomRedesignStandard ?? 1) === 1
                                  ? ''
                                  : 's'}
                              </strong>{' '}
                              per room redesign
                            </span>
                          </span>
                          <span data-testid="studio-credit-balance">
                            Available balance:{' '}
                            <strong className="text-[#1F4D3D]">
                              {accountSummary?.availableCredits ?? credits.freeTrialRemaining} credits
                              remaining
                            </strong>
                          </span>
                        </div>

                        <button
                          type="button"
                          disabled={isGenerating}
                          onClick={() => handleGenerateDesign(false)}
                          className="w-full py-4 px-6 rounded-xl bg-[#1F4D3D] hover:bg-[#153A2E] disabled:opacity-60 text-[#FFFFFF] font-semibold text-base shadow-xs transition-all flex items-center justify-center gap-2.5 cursor-pointer"
                        >
                          {isGenerating ? (
                            <>
                              <RefreshCw className="w-5 h-5 animate-spin" />
                              <span>{GENERATION_STEPS[generationStepIndex]}</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-5 h-5" />
                              <span>Generate My Design</span>
                            </>
                          )}
                        </button>

                        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-[#667067]">
                          <button
                            type="button"
                            onClick={() => navigateToRoute('/pricing')}
                            className="text-[#1F4D3D] font-semibold hover:underline cursor-pointer"
                          >
                            Need more credits? View Credit Packages →
                          </button>

                          <button
                            type="button"
                            onClick={handleResetCredits}
                            className="text-[#667067] hover:text-[#1C2420] underline cursor-pointer"
                          >
                            Reset demo trial session (3 credits)
                          </button>
                        </div>
                      </div>

                      {generationError && (
                        <div
                          role="alert"
                          data-testid="generation-error-alert"
                          className="mt-4 p-4 rounded-xl bg-[#EFE5D6]/70 border border-[#C2623F] text-xs sm:text-sm text-[#1C2420] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="flex items-start gap-2.5">
                            <AlertCircle className="w-5 h-5 text-[#C2623F] shrink-0 mt-0.5" />
                            <div className="space-y-1">
                              <p className="font-semibold">
                                {insufficientCreditsShown
                                  ? 'Insufficient Design Credits'
                                  : 'Unable to complete generation'}
                              </p>
                              <p className="text-[#667067]">{generationError}</p>
                            </div>
                          </div>
                          {insufficientCreditsShown && (
                            <button
                              type="button"
                              onClick={() => navigateToRoute('/pricing')}
                              className="px-4 py-2 rounded-xl bg-[#1F4D3D] text-[#FFFFFF] text-xs font-semibold hover:bg-[#153A2E] shrink-0 cursor-pointer"
                            >
                              Get More Credits
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* ACTIONABLE 3-PART RESULT VIEW (A. The Design, B. The Plan, C. The Shopping List) */}
                {result && (
                  <div
                    ref={resultSectionRef}
                    className="mt-12 bg-[#FFFFFF] rounded-3xl p-6 sm:p-8 lg:p-10 border-2 border-[#1F4D3D] shadow-sm scroll-mt-20 space-y-10"
                  >
                    {/* Top Result Header & Quick Actions */}
                    <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-[#E8E1D6]">
                      <div>
                        <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#1F4D3D] mb-1.5">
                          <span>
                            {result.mode === 'demo_fallback'
                              ? 'Demo Design Concept (Labeled Preview)'
                              : 'Live AI Room Redesign'}
                          </span>
                        </div>
                        <h3 className="text-2xl sm:text-3xl font-semibold text-[#1C2420]">
                          Your {result.preferences.style} {result.preferences.roomType} Plan
                        </h3>
                        <p className="text-xs sm:text-sm text-[#667067] mt-1">{result.modeReason}</p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2.5">
                        <button
                          type="button"
                          disabled={isGenerating}
                          onClick={() => handleGenerateDesign(true)}
                          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#F3EDE2] hover:bg-[#D9E7DC]/70 border border-[#E8E1D6] text-xs sm:text-sm font-semibold text-[#1C2420] transition-colors cursor-pointer"
                        >
                          <RefreshCw className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
                          <span>Regenerate</span>
                        </button>

                        <button
                          type="button"
                          onClick={handleDownloadResult}
                          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#1F4D3D] hover:bg-[#153A2E] text-xs sm:text-sm font-semibold text-[#FFFFFF] transition-colors cursor-pointer"
                        >
                          <Download className="w-4 h-4" />
                          <span>Download Concept</span>
                        </button>

                        <button
                          type="button"
                          onClick={handleStartOver}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-[#E8E1D6] hover:bg-[#FAF7F2] text-xs sm:text-sm font-medium text-[#667067] transition-colors cursor-pointer"
                        >
                          <RotateCcw className="w-4 h-4" />
                          <span>Start Over</span>
                        </button>
                      </div>
                    </div>

                    {/* SECTION A. THE DESIGN */}
                    <div id="result-the-design">
                      <div className="mb-4">
                        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1F4D3D]">
                          A. The Design
                        </p>
                        <h4 className="text-2xl font-semibold text-[#1C2420] mt-0.5">
                          Before &amp; After Room Concept
                        </h4>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                        <div className="lg:col-span-8">
                          <BeforeAfterSlider
                            beforeImage={result.originalImageDataUrl}
                            afterImage={result.redesignedImageDataUrl}
                            beforeLabel="Original Room"
                            afterLabel={
                              result.mode === 'demo_fallback'
                                ? 'Demo Design Concept'
                                : `${result.preferences.style} Redesign`
                            }
                            isDemoConcept={result.mode === 'demo_fallback'}
                            styleName={result.preferences.style}
                            roomTypeName={result.preferences.roomType}
                          />
                        </div>

                        <div className="lg:col-span-4 space-y-4">
                          <div className="bg-[#FAF7F2] p-5 rounded-2xl border border-[#E8E1D6] space-y-4">
                            <div>
                              <h5 className="text-base font-semibold text-[#1C2420] mb-2">
                                What You Already Own &amp; Keep
                              </h5>
                              <p className="text-xs text-[#667067] leading-relaxed">
                                <strong className="text-[#1C2420]">Strategy:</strong>{' '}
                                {
                                  EXISTING_FURNITURE_MODES.find(
                                    (m) => m.id === result.preferences.existingFurnitureMode
                                  )?.label
                                }
                              </p>
                              {result.preferences.identifiedFurniture.length > 0 && (
                                <p className="text-xs text-[#667067] mt-1">
                                  <strong className="text-[#1C2420]">Identified Items:</strong>{' '}
                                  {result.preferences.identifiedFurniture.join(', ')}
                                </p>
                              )}
                            </div>

                            <div className="pt-3 border-t border-[#E8E1D6]">
                              <h5 className="text-base font-semibold text-[#1C2420] mb-2">
                                Preserved Architectural Features
                              </h5>
                              <ul className="space-y-1">
                                {result.architecturalNotes.map((note, idx) => (
                                  <li
                                    key={idx}
                                    className="text-xs text-[#667067] flex items-start gap-2"
                                  >
                                    <Lock className="w-3.5 h-3.5 text-[#1F4D3D] shrink-0 mt-0.5" />
                                    <span>{note}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div className="pt-3 border-t border-[#E8E1D6]">
                              <h5 className="text-base font-semibold text-[#1C2420] mb-2">
                                Active Rental Restrictions
                              </h5>
                              <ul className="space-y-1">
                                {result.renterComplianceNotes.slice(0, 5).map((item, idx) => (
                                  <li
                                    key={idx}
                                    className="text-xs text-[#667067] flex items-start gap-2"
                                  >
                                    <Check className="w-3.5 h-3.5 text-[#1F4D3D] shrink-0 mt-0.5" />
                                    <span>{item}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {result.smallSpaceNotes.length > 0 && (
                              <div className="pt-3 border-t border-[#E8E1D6]">
                                <h5 className="text-base font-semibold text-[#1C2420] mb-2">
                                  Small-Space Solutions Applied
                                </h5>
                                <ul className="space-y-1">
                                  {result.smallSpaceNotes.map((note, idx) => (
                                    <li
                                      key={idx}
                                      className="text-xs text-[#667067] flex items-start gap-2"
                                    >
                                      <Maximize2 className="w-3.5 h-3.5 text-[#1F4D3D] shrink-0 mt-0.5" />
                                      <span>{note}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* SECTION B. THE PLAN */}
                    <div id="result-the-plan" className="pt-8 border-t border-[#E8E1D6]">
                      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
                        <div>
                          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1F4D3D]">
                            B. The Plan
                          </p>
                          <h4 className="text-2xl sm:text-3xl font-semibold text-[#1C2420] mt-0.5">
                            Step-by-Step Renter Action Plan
                          </h4>
                          <p className="text-xs sm:text-sm text-[#667067] mt-1">
                            Ordered from $0 free adjustments using what you already own to low-cost and optional upgrades.
                          </p>
                        </div>
                        <div className="flex flex-wrap items-center gap-2 text-xs text-[#667067]">
                          <span className="font-semibold text-[#1F4D3D]">1. Free Changes ($0)</span>
                          <span aria-hidden="true">·</span>
                          <span>2. Low-Cost Changes</span>
                          <span aria-hidden="true">·</span>
                          <span>3. Optional Higher-Cost</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {result.actionPlan.map((step) => (
                          <div
                            key={step.stepNumber}
                            className="p-5 rounded-2xl bg-[#FAF7F2] border border-[#E8E1D6] flex flex-col justify-between gap-3"
                          >
                            <div>
                              <div className="flex items-center justify-between gap-2 mb-2">
                                <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F4D3D]">
                                  <ClipboardList className="w-3.5 h-3.5" />
                                  <span>Step {step.stepNumber}</span>
                                </span>
                                <span className="text-xs font-medium text-[#667067]">
                                  {step.costLabel}
                                </span>
                              </div>
                              <h5 className="text-base font-semibold text-[#1C2420]">{step.title}</h5>
                              <p className="text-xs sm:text-sm text-[#667067] mt-1.5 leading-relaxed">
                                {step.description}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* SECTION C. THE SHOPPING LIST */}
                    <ShoppableSection
                      recommendations={result.recommendations}
                      budget={result.preferences.budget}
                      budgetSummary={result.budgetSummary}
                      budgetGuidance={result.budgetGuidance}
                      userVerifiedPrices={userVerifiedPrices}
                      onUpdateVerifiedPrice={handleUpdateVerifiedPrice}
                      onReviseToFitBudget={handleReviseResultToFitBudget}
                      sectionTitle="Budget-Aware Shopping List"
                      onProductClick={(product) =>
                        track('product_link_clicked', {
                          productId: product.id,
                          category: product.category,
                        })
                      }
                    />
                  </div>
                )}
              </div>
            </section>

            {/* 10. DESIGN STYLE GALLERY */}
            <section
              id="explore-styles"
              className="py-16 sm:py-24 bg-[#FAF7F2] border-b border-[#E8E1D6] scroll-mt-16"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
                  <div>
                    <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1F4D3D]">
                      Curated Interior Styles
                    </span>
                    <h2 className="text-3xl sm:text-4xl font-semibold text-[#1C2420] mt-2 tracking-tight">
                      Find Your Kind of Home
                    </h2>
                  </div>
                  <p className="text-sm text-[#667067]">
                    Select any style card below to apply it in the design studio.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {DESIGN_STYLES.map((styleObj) => {
                    const isSelected = preferences.style === styleObj.id;
                    return (
                      <div
                        key={styleObj.id}
                        onClick={() => handleSelectStyle(styleObj.id, true)}
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            handleSelectStyle(styleObj.id, true);
                          }
                        }}
                        className={`group rounded-2xl overflow-hidden bg-[#FFFFFF] border transition-all cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'border-[#1F4D3D] ring-2 ring-[#1F4D3D] shadow-sm'
                            : 'border-[#E8E1D6] hover:border-[#1F4D3D]/50 shadow-2xs'
                        }`}
                      >
                        <div>
                          <div className="relative aspect-[16/10] bg-[#EFE5D6] overflow-hidden">
                            <img
                              src={styleCardImages[styleObj.id]}
                              alt={styleObj.label}
                              className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                            />
                            <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#1C2420]/80 backdrop-blur-xs text-[#FFFFFF] text-xs font-medium">
                              {styleObj.label}
                            </div>
                          </div>

                          <div className="p-6">
                            <h3 className="text-xl font-semibold text-[#1C2420]">{styleObj.label}</h3>
                            <p className="text-sm text-[#667067] mt-1.5 leading-relaxed">
                              {styleObj.tagline}
                            </p>
                            <p className="text-xs text-[#667067] mt-3">
                              <strong className="text-[#1C2420]">Key Materials:</strong>{' '}
                              {styleObj.materials}
                            </p>
                          </div>
                        </div>

                        <div className="px-6 pb-5 pt-3 border-t border-[#E8E1D6] flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            {styleObj.swatches.map((hex, idx) => (
                              <span
                                key={idx}
                                className="w-4 h-4 rounded-full border border-black/15"
                                style={{ backgroundColor: hex }}
                              />
                            ))}
                          </div>
                          <span className="text-xs font-semibold text-[#1F4D3D] group-hover:underline inline-flex items-center gap-1">
                            <span>Select {styleObj.label}</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </section>

            {/* 11. BUDGET-AWARE DESIGN PREVIEW */}
            <section
              id="budget-preview"
              className="py-16 sm:py-24 bg-[#FFFFFF] border-b border-[#E8E1D6]"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
                {/* Step 1: Free $0 Existing-Furniture Steps First */}
                <div className="bg-[#FAF7F2] rounded-2xl p-6 sm:p-8 border border-[#E8E1D6]">
                  <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
                    <div>
                      <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1F4D3D]">
                        Step 1 · Start With $0 Changes First
                      </span>
                      <h3 className="text-xl sm:text-2xl font-semibold text-[#1C2420] mt-1">
                        Rearrange &amp; Style What You Already Own
                      </h3>
                      <p className="text-sm text-[#667067] mt-1">
                        Before buying anything new, every Eden Canvas plan outlines zero-cost layout, lighting, and decluttering steps tailored to your room.
                      </p>
                    </div>
                    <span className="text-xs font-semibold text-[#1F4D3D]">
                      {previewFreeSteps.length} Free Action Steps ($0)
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {previewFreeSteps.map((step) => (
                      <div
                        key={step.stepNumber}
                        className="p-4 rounded-xl bg-[#FFFFFF] border border-[#E8E1D6]"
                      >
                        <div className="flex items-center justify-between text-xs mb-1.5">
                          <span className="font-semibold text-[#1F4D3D]">
                            Step {step.stepNumber} · Free Adjustment
                          </span>
                          <span className="text-[#667067]">{step.costLabel}</span>
                        </div>
                        <h4 className="text-sm font-semibold text-[#1C2420]">{step.title}</h4>
                        <p className="text-xs text-[#667067] mt-1 leading-relaxed">
                          {step.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Step 2: Optional Purchases, Verified Prices & Budget Comparison */}
                <ShoppableSection
                  recommendations={previewRecResult.items}
                  budget={preferences.budget}
                  budgetSummary={previewRecResult.budgetSummary}
                  budgetGuidance={previewRecResult.budgetGuidance}
                  userVerifiedPrices={userVerifiedPrices}
                  onUpdateVerifiedPrice={handleUpdateVerifiedPrice}
                  onReviseToFitBudget={handleReviseHomepagePreviewBudget}
                  standalone={true}
                  sectionTitle="Know Your Plan Before You Shop"
                  onProductClick={(product) =>
                    track('product_link_clicked', {
                      productId: product.id,
                      category: product.category,
                    })
                  }
                />
              </div>
            </section>

            {/* 13. TRUST AND PRIVACY SECTION */}
            <section
              id="trust-privacy"
              className="py-16 sm:py-20 bg-[#FFFFFF] border-b border-[#E8E1D6]"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-3xl mb-10">
                  <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1F4D3D]">
                    Trust &amp; Transparency
                  </span>
                  <h2 className="text-3xl sm:text-4xl font-semibold text-[#1C2420] mt-2 tracking-tight">
                    Your Space, Your Choices
                  </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="p-5 rounded-2xl bg-[#FAF7F2] border border-[#E8E1D6]">
                    <h3 className="text-base font-semibold text-[#1C2420]">
                      Start With Your Own Room
                    </h3>
                    <p className="text-xs text-[#667067] mt-1.5 leading-relaxed">
                      Your uploaded room photo is used only to generate your design concept during your active session.
                    </p>
                  </div>

                  <div className="p-5 rounded-2xl bg-[#FAF7F2] border border-[#E8E1D6]">
                    <h3 className="text-base font-semibold text-[#1C2420]">
                      Concepts for Inspiration
                    </h3>
                    <p className="text-xs text-[#667067] mt-1.5 leading-relaxed">
                      Generated visuals are conceptual previews to help you plan—not a guarantee of exact retail product dimensions or finishes.
                    </p>
                  </div>

                  <div className="p-5 rounded-2xl bg-[#FAF7F2] border border-[#E8E1D6]">
                    <h3 className="text-base font-semibold text-[#1C2420]">
                      Optional Product Suggestions
                    </h3>
                    <p className="text-xs text-[#667067] mt-1.5 leading-relaxed">
                      Every plan prioritizes free adjustments with furniture you already own before suggesting optional retail upgrades.
                    </p>
                  </div>

                  <div className="p-5 rounded-2xl bg-[#FAF7F2] border border-[#E8E1D6]">
                    <h3 className="text-base font-semibold text-[#1C2420]">
                      You Stay in Control
                    </h3>
                    <p className="text-xs text-[#667067] mt-1.5 leading-relaxed">
                      Lock your rental rules, set your own spending cap, and explore at your own pace with transparent credit accounting.
                    </p>
                  </div>
                </div>

                <div className="mt-8 flex flex-wrap items-center gap-6 text-xs font-medium text-[#1F4D3D]">
                  <button
                    type="button"
                    onClick={() => setLegalModal('privacy')}
                    className="hover:underline cursor-pointer"
                  >
                    Privacy Policy
                  </button>
                  <button
                    type="button"
                    onClick={() => setLegalModal('terms')}
                    className="hover:underline cursor-pointer"
                  >
                    Terms of Service
                  </button>
                  <button
                    type="button"
                    onClick={() => setLegalModal('refund')}
                    className="hover:underline cursor-pointer"
                  >
                    Refund Policy
                  </button>
                  <button
                    type="button"
                    onClick={() => setLegalModal('contact')}
                    className="hover:underline cursor-pointer"
                  >
                    Contact
                  </button>
                </div>
              </div>
            </section>
          </>
        ) : (
          <>
            {/* HERO — simple, trustworthy, one clear action */}
            <section className="relative overflow-hidden bg-[linear-gradient(180deg,#FAF7F2_0%,#FFFFFF_100%)] pt-10 pb-14 sm:pt-16 sm:pb-20 border-b border-[#E8E1D6]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
                  <div className="lg:col-span-5 space-y-6">
                    <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#FFFFFF] border border-[#E8E1D6] text-xs font-semibold text-[#1C2420] shadow-2xs">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C2623F]" aria-hidden="true" />
                      Built for renters everywhere
                    </span>

                    <h1 className="text-4xl sm:text-5xl lg:text-[3.4rem] font-semibold leading-[1.06] tracking-tight text-[#1C2420] text-balance">
                      Make your rental feel like home.
                    </h1>

                    <p className="text-base sm:text-lg text-[#667067] leading-relaxed max-w-xl">
                      See your real room redesigned around your style, your budget, and your lease — before you buy a thing.
                    </p>

                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-1">
                      <button
                        type="button"
                        onClick={scrollToWorkspace}
                        className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl bg-[#1F4D3D] text-[#FFFFFF] text-base font-semibold hover:bg-[#153A2E] transition-colors shadow-sm cursor-pointer whitespace-nowrap"
                      >
                        <span>Try Free</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => scrollToSection('showcase')}
                        className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#FFFFFF] text-[#1C2420] border border-[#E8E1D6] text-base font-medium hover:bg-[#FAF7F2] transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <span>See Examples</span>
                      </button>
                    </div>

                    <ul className="flex flex-wrap gap-x-5 gap-y-2 pt-1 text-xs sm:text-sm font-medium text-[#667067]">
                      <li className="inline-flex items-center gap-1.5"><Check className="w-4 h-4 text-[#1F4D3D]" />3 free credits</li>
                      <li className="inline-flex items-center gap-1.5"><Check className="w-4 h-4 text-[#1F4D3D]" />No card required</li>
                      <li className="inline-flex items-center gap-1.5"><Check className="w-4 h-4 text-[#1F4D3D]" />No painting or drilling</li>
                    </ul>
                  </div>

                  <div className="lg:col-span-7">
                    <div className="bg-[#FFFFFF] p-3 sm:p-4 rounded-3xl border border-[#E8E1D6] shadow-[0_20px_50px_-20px_rgba(31,77,61,0.25)]">
                      <BeforeAfterSlider
                        beforeImage={heroVisuals.before}
                        afterImage={heroVisuals.after}
                        beforeLabel="Original Room"
                        afterLabel="Demo Design Concept"
                        isDemoConcept={true}
                        styleName="Organic Modern"
                        roomTypeName="Living Room"
                      />
                      <p className="mt-3 px-1 text-xs text-[#667067]">
                        <span className="font-semibold text-[#1C2420]">Organic Modern living room</span> · Walls, windows, and flooring preserved
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* TRUST STRIP — factual product promises only */}
            <section className="bg-[#FFFFFF] border-b border-[#E8E1D6]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                {[
                  { icon: ShieldCheck, title: 'Lease-safe ideas', text: 'No painting, drilling, or hardwiring' },
                  { icon: Home, title: 'Keeps your furniture', text: 'Start with what you already own' },
                  { icon: Wallet, title: 'Fits your budget', text: 'Set a spending cap, even $0' },
                  { icon: RefreshCw, title: 'Credit-safe', text: 'Failed generations are refunded' },
                ].map((item) => (
                  <div key={item.title} className="flex items-start gap-3">
                    <span className="w-9 h-9 rounded-xl bg-[#D9E7DC] text-[#1F4D3D] flex items-center justify-center shrink-0">
                      <item.icon className="w-4.5 h-4.5" />
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-[#1C2420]">{item.title}</p>
                      <p className="text-xs text-[#667067] mt-0.5 leading-snug">{item.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* 9. HOW IT WORKS SECTION */}
            <section
              id="how-it-works"
              className="py-16 sm:py-24 bg-[#FFFFFF] border-b border-[#E8E1D6] scroll-mt-16"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-3xl mb-12">
                  <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1F4D3D]">
                    How It Works
                  </span>
                  <h2 className="text-3xl sm:text-4xl font-semibold text-[#1C2420] mt-2 tracking-tight">
                    Your Room Refresh in Three Simple Steps
                  </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
                  <div className="rounded-2xl p-6 sm:p-8 bg-[#FAF7F2] border border-[#E8E1D6]">
                    <span className="inline-flex items-center justify-center px-3 py-1 rounded-lg bg-[#D9E7DC] text-[#1F4D3D] font-semibold text-xs mb-4">
                      01
                    </span>
                    <h3 className="text-xl font-semibold text-[#1C2420]">Upload Your Room</h3>
                    <p className="text-sm sm:text-base text-[#667067] mt-2 leading-relaxed">
                      Start with a photo of your existing space.
                    </p>
                  </div>

                  <div className="rounded-2xl p-6 sm:p-8 bg-[#FAF7F2] border border-[#E8E1D6]">
                    <span className="inline-flex items-center justify-center px-3 py-1 rounded-lg bg-[#D9E7DC] text-[#1F4D3D] font-semibold text-xs mb-4">
                      02
                    </span>
                    <h3 className="text-xl font-semibold text-[#1C2420]">Set Your Preferences</h3>
                    <p className="text-sm sm:text-base text-[#667067] mt-2 leading-relaxed">
                      Choose your style, budget, furniture preferences, and rental restrictions.
                    </p>
                  </div>

                  <div className="rounded-2xl p-6 sm:p-8 bg-[#FAF7F2] border border-[#E8E1D6]">
                    <span className="inline-flex items-center justify-center px-3 py-1 rounded-lg bg-[#D9E7DC] text-[#1F4D3D] font-semibold text-xs mb-4">
                      03
                    </span>
                    <h3 className="text-xl font-semibold text-[#1C2420]">Explore Your New Look</h3>
                    <p className="text-sm sm:text-base text-[#667067] mt-2 leading-relaxed">
                      Review your design concept and follow a practical room refresh plan.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* 7. BEFORE-AND-AFTER SHOWCASE SECTION */}
            <section
              id="showcase"
              className="py-16 sm:py-24 bg-[#FFFFFF] border-b border-[#E8E1D6] scroll-mt-16"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-2xl mb-10 sm:mb-12">
                  <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#C2623F]">
                    Before &amp; After
                  </span>
                  <h2 className="text-3xl sm:text-4xl font-semibold text-[#1C2420] mt-2 tracking-tight">
                    See what your space could become
                  </h2>
                  <p className="text-base sm:text-lg text-[#667067] mt-3 leading-relaxed">
                    Real rental layouts, restyled without painting, drilling, or permanent changes.
                  </p>
                </div>

                <ShowcaseCarousel
                  items={showcaseTransformations}
                  onTryRoom={(id) => {
                    const preset = SAMPLE_ROOM_PRESETS.find((p) => p.id === id);
                    if (preset) handleSelectSampleRoom(preset);
                    scrollToWorkspace();
                  }}
                />
              </div>
            </section>

            {/* 8. RENTER-FRIENDLY DIFFERENTIATION SECTION */}
            <section
              id="renter-friendly"
              className="py-16 sm:py-24 bg-[#F3EDE2] border-b border-[#E8E1D6] scroll-mt-16"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-3xl mb-12">
                  <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1F4D3D]">
                    Renter-Friendly Design
                  </span>
                  <h2 className="text-3xl sm:text-4xl font-semibold text-[#1C2420] mt-2 tracking-tight">
                    Beautiful Design. Rental-Friendly Decisions.
                  </h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                    <div className="w-10 h-10 rounded-xl bg-[#D9E7DC] text-[#1F4D3D] flex items-center justify-center mb-4">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <h3 className="text-lg font-semibold text-[#1C2420]">
                      No Permanent Changes
                    </h3>
                    <p className="text-sm text-[#667067] mt-2 leading-relaxed">
                      Design around restrictions like no painting, no drilling, and no hardwired changes.
                    </p>
                  </div>

                  <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                    <div className="w-10 h-10 rounded-xl bg-[#D9E7DC] text-[#1F4D3D] flex items-center justify-center mb-4">
                      <Wallet className="w-5 h-5" />
                    </div>
                    <h3 className="text-lg font-semibold text-[#1C2420]">
                      Designed Around Your Budget
                    </h3>
                    <p className="text-sm text-[#667067] mt-2 leading-relaxed">
                      Explore ideas that work with what you already own or within a realistic spending plan.
                    </p>
                  </div>

                  <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                    <div className="w-10 h-10 rounded-xl bg-[#D9E7DC] text-[#1F4D3D] flex items-center justify-center mb-4">
                      <Home className="w-5 h-5" />
                    </div>
                    <h3 className="text-lg font-semibold text-[#1C2420]">
                      Work With What You Own
                    </h3>
                    <p className="text-sm text-[#667067] mt-2 leading-relaxed">
                      Start with your real room and keep the furniture that already works.
                    </p>
                  </div>

                  <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#E8E1D6]">
                    <div className="w-10 h-10 rounded-xl bg-[#D9E7DC] text-[#1F4D3D] flex items-center justify-center mb-4">
                      <Maximize2 className="w-5 h-5" />
                    </div>
                    <h3 className="text-lg font-semibold text-[#1C2420]">
                      Make Small Spaces Work Harder
                    </h3>
                    <p className="text-sm text-[#667067] mt-2 leading-relaxed">
                      Discover layout and styling ideas for apartments, studios, and compact rooms.
                    </p>
                  </div>
                </div>

                <p className="mt-6 text-xs text-[#667067]">
                  Note: Residential lease agreements and wall finishes vary; always review your lease terms before using removable adhesives or hardware.
                </p>
              </div>
            </section>
            {/* 14. FREQUENTLY ASKED QUESTIONS */}
            <section id="faq" className="py-16 sm:py-24 bg-[#FFFFFF] border-b border-[#E8E1D6]">
              <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                  <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1F4D3D]">
                    Common Questions
                  </span>
                  <h2 className="text-3xl sm:text-4xl font-semibold text-[#1C2420] mt-2 tracking-tight">
                    Quick Answers
                  </h2>
                </div>

                <div className="space-y-3">
                  {HOME_FAQ_ITEMS.map((item, idx) => {
                    const isOpen = openFaqIndex === idx;
                    return (
                      <div
                        key={idx}
                        className="bg-[#FFFFFF] rounded-2xl border border-[#E8E1D6] overflow-hidden"
                      >
                        <button
                          type="button"
                          onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                          aria-expanded={isOpen}
                          className="w-full px-6 py-4 text-left flex items-center justify-between gap-4 hover:bg-[#FAF7F2] transition-colors cursor-pointer"
                        >
                          <span className="text-base sm:text-lg font-semibold text-[#1C2420]">
                            {item.question}
                          </span>
                          {isOpen ? (
                            <ChevronUp className="w-5 h-5 text-[#1F4D3D] shrink-0" />
                          ) : (
                            <ChevronDown className="w-5 h-5 text-[#667067] shrink-0" />
                          )}
                        </button>
                        {isOpen && (
                          <div className="px-6 pb-5 text-sm text-[#667067] leading-relaxed border-t border-[#E8E1D6] pt-3">
                            {item.answer}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </section>

            {/* FINAL CTA */}
            <section className="py-16 sm:py-20 bg-[#1F4D3D] text-[#FFFFFF]">
              <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center">
                <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-balance">
                  Your next room refresh starts with one photo.
                </h2>
                <p className="mt-3 text-base text-[#D9E7DC]">
                  Try it free with 3 credits. No card, no commitment.
                </p>
                <button
                  type="button"
                  onClick={scrollToWorkspace}
                  className="mt-8 inline-flex items-center gap-2.5 px-8 py-4 rounded-xl bg-[#FAF7F2] text-[#1F4D3D] text-base font-semibold hover:bg-[#FFFFFF] transition-colors shadow-md cursor-pointer"
                >
                  <span>Try Free</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </section>
          </>
        )}
      </main>

      {/* 15. CLEAN WHITE FOOTER */}
      <footer className="bg-[#FFFFFF] border-t border-[#E8E1D6] py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
            <div className="max-w-sm">
              <div className="flex items-center gap-2.5">
                <img
                  src="/images/eden-canvas-logo.png"
                  alt="Eden Canvas"
                  width={1200}
                  height={192}
                  className="h-7 w-auto select-none"
                  draggable={false}
                />
              </div>
              <p className="text-xs text-[#667067] mt-2 leading-relaxed">
                AI-powered interior redesign for renters everywhere. Visualize rooms that fit your style,
                your budget, and your rental restrictions before you buy a thing.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-[#667067]">
              <button
                type="button"
                onClick={scrollToWorkspace}
                className="hover:text-[#1C2420] cursor-pointer"
              >
                Try Free
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('how-it-works')}
                className="hover:text-[#1C2420] cursor-pointer"
              >
                How It Works
              </button>
              <button
                type="button"
                onClick={() => goToTry('explore-styles')}
                className="hover:text-[#1C2420] cursor-pointer"
              >
                Explore Styles
              </button>
              <button
                type="button"
                onClick={() => navigateToRoute('/pricing')}
                className="text-[#1F4D3D] font-semibold hover:underline cursor-pointer"
              >
                Pricing
              </button>
              <button
                type="button"
                onClick={() => setLegalModal('contact')}
                className="hover:text-[#1C2420] cursor-pointer"
              >
                Help / Support
              </button>
              <button
                type="button"
                onClick={() => setLegalModal('privacy')}
                className="hover:text-[#1C2420] cursor-pointer"
              >
                Privacy Policy
              </button>
              <button
                type="button"
                onClick={() => setLegalModal('terms')}
                className="hover:text-[#1C2420] cursor-pointer"
              >
                Terms of Service
              </button>
              <button
                type="button"
                onClick={() => setLegalModal('refund')}
                className="hover:text-[#1C2420] cursor-pointer"
              >
                Refund Policy
              </button>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-[#E8E1D6] flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#667067]">
            <span>© {new Date().getFullYear()} Wold Eden · Eden Canvas</span>
            <span>
              AI room redesigns are conceptual visualizations—not guarantees of exact retail product
              appearance, dimensions, or final room outcomes.
            </span>
          </div>
        </div>
      </footer>

      {/* Legal / Refund / Contact / Log In Modal */}
      {legalModal && (
        <div
          className="fixed inset-0 z-50 bg-black/45 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#FFFFFF] rounded-2xl max-w-lg w-full p-6 border border-[#E8E1D6] shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#E8E1D6]">
              <h3 className="text-lg font-semibold text-[#1C2420] flex items-center gap-2">
                {legalModal === 'login' && (
                  <>
                    <User className="w-4 h-4 text-[#1F4D3D]" />
                    <span>Account Session Status</span>
                  </>
                )}
                {legalModal === 'privacy' && 'Draft Privacy Policy — Owner Review Required'}
                {legalModal === 'terms' && 'Draft Terms of Service — Owner Review Required'}
                {legalModal === 'refund' && 'Draft Refund Policy — Owner Review Required'}
                {legalModal === 'contact' && 'Help & Customer Support (Draft)'}
              </h3>
              <button
                type="button"
                onClick={() => setLegalModal(null)}
                className="p-1.5 rounded-lg text-[#667067] hover:bg-[#FAF7F2]"
                aria-label="Close modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-4 text-xs sm:text-sm text-[#667067] space-y-3 leading-relaxed">
              {legalModal === 'login' ? (
                <>
                  <p className="text-[#1C2420] font-medium">
                    No password sign-in is required in this interactive prototype.
                  </p>
                  <p>
                    Your browser is automatically connected to an isolated server-side credit ledger
                    session (<code>{accountId || 'active-session'}</code>) with{' '}
                    <strong className="text-[#1F4D3D]">
                      {accountSummary?.availableCredits ?? credits.freeTrialRemaining} available
                      design credits
                    </strong>
                    .
                  </p>
                  <p className="text-xs bg-[#FAF7F2] p-3 rounded-xl border border-[#E8E1D6]">
                    <strong>Production Note:</strong> Full user authentication (OAuth / email login)
                    must be connected before enabling live cross-device account persistence.
                  </p>
                </>
              ) : (
                <>
                  <p className="font-semibold text-[#1F4D3D]">
                    [DRAFT POLICY FOR OWNER REVIEW PRIOR TO COMMERCIAL LAUNCH]
                  </p>
                  {legalModal === 'privacy' && (
                    <p>
                      Uploaded room photos are processed solely to generate your requested room
                      design concept during your active session. Eden Canvas does not sell your
                      photos, collect raw credit-card data on its servers, or expose private room
                      images in analytics.
                    </p>
                  )}
                  {legalModal === 'terms' && (
                    <p>
                      Eden Canvas provides visual interior design concepts for inspiration.
                      Generated images are concepts, not guarantees of exact product appearance,
                      dimensions, or final room outcomes. Users are responsible for reviewing their
                      lease agreement and measuring physical clearances.
                    </p>
                  )}
                  {legalModal === 'refund' && (
                    <p>
                      If an AI room generation fails due to a technical or provider error, the
                      deducted design credit is automatically refunded to your account balance.
                      Monetary refund windows for one-time credit package purchases must be
                      configured and approved by the business owner before activating live payments.
                    </p>
                  )}
                  {legalModal === 'contact' && (
                    <p>
                      This is the interactive prototype of Eden Canvas by Wold Eden. The business
                      owner must configure an official customer support email or help desk channel
                      prior to production launch.
                    </p>
                  )}
                </>
              )}
            </div>

            <div className="pt-3 border-t border-[#E8E1D6] flex items-center justify-end gap-2.5">
              {legalModal === 'login' && (
                <button
                  type="button"
                  onClick={() => {
                    setLegalModal(null);
                    navigateToRoute('/pricing', 'credit-ledger-section');
                  }}
                  className="px-4 py-2 rounded-xl bg-[#FAF7F2] border border-[#E8E1D6] text-[#1C2420] text-xs font-semibold hover:bg-[#D9E7DC]/50 cursor-pointer"
                >
                  View Credit Ledger
                </button>
              )}
              <button
                type="button"
                onClick={() => setLegalModal(null)}
                className="px-4 py-2 rounded-xl bg-[#1F4D3D] text-[#FFFFFF] text-xs font-semibold hover:bg-[#153A2E] cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
